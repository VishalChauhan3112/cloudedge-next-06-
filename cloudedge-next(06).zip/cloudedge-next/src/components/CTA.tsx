import { ArrowRight } from "lucide-react";
import Reveal from "./Reveal";

export default function CTA({
  title = "Let's Build Something Great",
  subtitle = "We craft technology solutions that help businesses grow, connect, and stay secure — let's talk about what you need.",
  primaryLabel = "Hire Us Now",
  primaryHref = "/#contact",
  secondaryLabel,
  secondaryHref,
}: {
  title?: string;
  subtitle?: string;
  primaryLabel?: string;
  primaryHref?: string;
  secondaryLabel?: string;
  secondaryHref?: string;
}) {
  return (
    <section className="relative mx-6 my-6 overflow-hidden rounded-3xl border border-wire bg-panel px-6 py-20 text-center md:mx-10 md:px-10">
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.08]"
        style={{
          backgroundImage:
            "linear-gradient(to right, var(--fog) 1px, transparent 1px), linear-gradient(to bottom, var(--fog) 1px, transparent 1px)",
          backgroundSize: "48px 48px",
          maskImage: "radial-gradient(ellipse 70% 60% at 50% 50%, black 30%, transparent 100%)",
        }}
      />
      <Reveal className="relative">
        <h2 className="mx-auto max-w-2xl font-display text-5xl leading-[0.95] text-fog md:text-6xl">
          {title}
        </h2>
        <p className="mx-auto mt-6 max-w-lg text-[14.5px] leading-relaxed text-fog-dim">
          {subtitle}
        </p>
        <div className="mt-9 flex flex-wrap items-center justify-center gap-4">
          <a
            href={primaryHref}
            className="group inline-flex items-center gap-2 rounded-full bg-signal px-8 py-4 font-mono text-[13px] font-medium tracking-wide text-white transition-transform hover:scale-[1.03]"
          >
            {primaryLabel}
            <ArrowRight size={15} className="transition-transform group-hover:translate-x-0.5" />
          </a>
          {secondaryLabel && secondaryHref && (
            <a
              href={secondaryHref}
              className="inline-flex items-center gap-2 rounded-full border border-wire-light px-8 py-4 font-mono text-[13px] tracking-wide text-fog transition-colors hover:border-signal/60 hover:text-signal-soft"
            >
              {secondaryLabel}
            </a>
          )}
        </div>
      </Reveal>
    </section>
  );
}
