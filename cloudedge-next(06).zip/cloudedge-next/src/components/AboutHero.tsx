import { ArrowRight } from "lucide-react";
import Eyebrow from "./Eyebrow";
import Reveal from "./Reveal";

export default function AboutHero() {
  return (
    <section className="relative overflow-hidden pt-40 pb-20 md:pt-48">
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.35]"
        style={{
          backgroundImage:
            "linear-gradient(to right, var(--wire) 1px, transparent 1px), linear-gradient(to bottom, var(--wire) 1px, transparent 1px)",
          backgroundSize: "64px 64px",
          maskImage: "radial-gradient(ellipse 80% 60% at 50% 0%, black 40%, transparent 100%)",
        }}
      />
      <div className="pointer-events-none absolute -top-40 left-1/2 h-[560px] w-[560px] -translate-x-1/2 rounded-full bg-signal/[0.07] blur-[140px]" />

      <div className="relative mx-auto max-w-4xl px-6 text-center md:px-10">
        <Reveal className="flex justify-center">
          <Eyebrow index="—" label="Who We Are" />
        </Reveal>
        <Reveal delay={0.05}>
          <h1 className="mt-6 font-display text-6xl leading-[0.92] text-fog md:text-7xl">
            We Lead Change,
            <br />
            Not Follow
          </h1>
        </Reveal>
        <Reveal delay={0.1}>
          <p className="mx-auto mt-8 max-w-2xl text-[15px] leading-relaxed text-fog-dim">
            At CloudEdge Tech Services, we don&apos;t just adapt to change — we lead it. With a
            strong footprint across India and the US, we empower businesses and professionals to
            stay ahead with innovative strategies and intelligent solutions.
          </p>
        </Reveal>
        <Reveal delay={0.15} className="mt-10 flex flex-wrap items-center justify-center gap-4">
          <a
            href="/#contact"
            className="group inline-flex items-center gap-2 rounded-full bg-signal px-7 py-3.5 font-mono text-[13px] font-medium tracking-wide text-white transition-transform hover:scale-[1.03]"
          >
            Work With Us
            <ArrowRight size={15} className="transition-transform group-hover:translate-x-0.5" />
          </a>
          <a
            href="/#services"
            className="inline-flex items-center gap-2 rounded-full border border-wire-light px-7 py-3.5 font-mono text-[13px] tracking-wide text-fog transition-colors hover:border-signal/60 hover:text-signal-soft"
          >
            Our Services
          </a>
        </Reveal>
      </div>
    </section>
  );
}
