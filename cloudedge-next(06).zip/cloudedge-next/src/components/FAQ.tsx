"use client";

import { useState } from "react";
import { Plus } from "lucide-react";
import Reveal from "./Reveal";
import Eyebrow from "./Eyebrow";

const FAQS = [
  {
    q: "What services does CloudEdge provide?",
    a: "We provide AI and technology solutions, SaaS development and consulting, managed IT services, cybersecurity, recruitment and staffing, digital marketing, international call center support, and IT training with mentorship.",
  },
  {
    q: "Do you work with startups, SMBs, and enterprise clients?",
    a: "Yes. We work with early-stage startups, growing SMBs, and enterprise teams. Our engagement model is tailored to your scale, priorities, and budget.",
  },
  {
    q: "How quickly can your team start a project?",
    a: "Most projects start within 3 to 7 business days after discovery. For urgent IT support and cybersecurity incidents, we can start triage the same day.",
  },
  {
    q: "Can you provide dedicated staffing and remote teams?",
    a: "Absolutely. We provide recruitment and staffing support for technical and non-technical roles, including dedicated remote teams aligned with your business goals.",
  },
  {
    q: "How do we get started with CloudEdge?",
    a: "You can send us a message through the contact form or book a call from the Schedule page. We will discuss your needs, define scope, and share a clear action plan with next steps.",
  },
];

export default function FAQ() {
  const [openIdx, setOpenIdx] = useState<number | null>(0);

  return (
    <section id="faq" className="mx-auto max-w-5xl px-6 py-28 md:px-10">
      <Reveal>
        <Eyebrow index="06" label="FAQ" />
        <h2 className="mt-5 font-display text-5xl leading-[0.95] text-fog md:text-6xl">
          Answers You Need Fast
        </h2>
        <p className="mt-6 max-w-xl text-[14.5px] leading-relaxed text-fog-dim">
          Everything you need to know before starting with CloudEdge Tech Services, from
          onboarding to security and support coverage.
        </p>
      </Reveal>

      <Reveal delay={0.1} className="mt-14 divide-y divide-wire border-t border-b border-wire">
        {FAQS.map((item, i) => {
          const isOpen = openIdx === i;
          return (
            <div key={item.q}>
              <button
                type="button"
                onClick={() => setOpenIdx(isOpen ? null : i)}
                aria-expanded={isOpen}
                className="flex w-full items-center justify-between gap-6 py-6 text-left"
              >
                <span className="text-[15.5px] font-medium text-fog">{item.q}</span>
                <Plus
                  size={18}
                  className={`shrink-0 text-signal-soft transition-transform duration-300 ${
                    isOpen ? "rotate-45" : ""
                  }`}
                />
              </button>
              <div
                className="grid overflow-hidden transition-all duration-300 ease-out"
                style={{ gridTemplateRows: isOpen ? "1fr" : "0fr" }}
              >
                <div className="overflow-hidden">
                  <p className="max-w-2xl pb-6 text-[13.5px] leading-relaxed text-fog-dim">
                    {item.a}
                  </p>
                </div>
              </div>
            </div>
          );
        })}
      </Reveal>
    </section>
  );
}
