import Reveal from "./Reveal";
import Eyebrow from "./Eyebrow";

const REGIONS = [
  {
    flag: "🇮🇳",
    name: "India",
    role: "Headquarters & Operations Hub",
  },
  {
    flag: "🇺🇸",
    name: "United States",
    role: "Enterprise & Fortune 500 Partnerships",
  },
];

const STATS = [
  { value: "2", suffix: "+", label: "Countries", sub: "India & US" },
  { value: "500", suffix: "+", label: "Clients Served", sub: "Across 12 Industries" },
  { value: "3", suffix: "+", label: "Years Experience", sub: "Since 2023" },
];

export default function Footprint() {
  return (
    <section id="footprint" className="border-t border-wire bg-panel/40">
      <div className="mx-auto max-w-7xl px-6 py-28 md:px-10">
        <Reveal>
          <Eyebrow index="01" label="Global Presence" />
          <h2 className="mt-5 max-w-2xl font-display text-5xl leading-[0.95] text-fog md:text-6xl">
            Driving Measurable Growth, Globally
          </h2>
          <p className="mt-6 max-w-2xl text-[14.5px] leading-relaxed text-fog-dim">
            We operate as a global consulting and technology partner committed to driving
            measurable outcomes — combining worldwide expertise with deep local insight, from
            building high-performance teams to enabling AI-driven transformation.
          </p>
        </Reveal>

        <div className="mt-14 grid gap-4 md:grid-cols-2">
          {REGIONS.map((r, i) => (
            <Reveal
              key={r.name}
              delay={i * 0.1}
              className="flex items-center gap-4 rounded-2xl border border-wire bg-panel px-7 py-6 shadow-[0_2px_12px_rgba(23,21,31,0.04)]"
            >
              <span className="text-3xl">{r.flag}</span>
              <div>
                <div className="text-[16px] font-medium text-fog">{r.name}</div>
                <div className="font-mono text-[12px] text-fog-dimmer">{r.role}</div>
              </div>
            </Reveal>
          ))}
        </div>

        <div className="mt-16 grid grid-cols-3 gap-8 border-t border-wire pt-12">
          {STATS.map((s, i) => (
            <Reveal key={s.label} delay={i * 0.08}>
              <div className="font-display text-4xl text-fog md:text-5xl">
                {s.value}
                <span className="text-signal">{s.suffix}</span>
              </div>
              <div className="mt-2 text-[13.5px] text-fog">{s.label}</div>
              <div className="font-mono text-[11px] text-fog-dimmer">{s.sub}</div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
