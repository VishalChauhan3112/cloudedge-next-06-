import { Brain, Code2, Headphones, Users, Megaphone, GraduationCap, ShieldCheck } from "lucide-react";
import type { ServiceIconName } from "@/lib/services";

const ICONS = {
  brain: Brain,
  code: Code2,
  headphones: Headphones,
  users: Users,
  megaphone: Megaphone,
  "graduation-cap": GraduationCap,
  "shield-check": ShieldCheck,
};

export default function ServiceIcon({
  name,
  size = 18,
  strokeWidth = 1.5,
}: {
  name: ServiceIconName;
  size?: number;
  strokeWidth?: number;
}) {
  const Icon = ICONS[name];
  return <Icon size={size} strokeWidth={strokeWidth} />;
}
