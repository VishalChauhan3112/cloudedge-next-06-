import Reveal from "./Reveal";
import Eyebrow from "./Eyebrow";

const VALUES = [
  {
    n: "01",
    title: "Precision",
    desc: "Every solution we design is meticulously crafted to address the specific needs of our clients. We don't believe in one-size-fits-all — we believe in exactly right.",
  },
  {
    n: "02",
    title: "Speed",
    desc: "In today's digital landscape, velocity matters. We move fast without sacrificing quality, enabling our clients to seize opportunities before the competition does.",
  },
  {
    n: "03",
    title: "Long-Term Value",
    desc: "We build partnerships, not transactions. Every engagement is designed to create sustainable advantage that compounds over time and grows with your business.",
  },
  {
    n: "04",
    title: "Innovation",
    desc: "We lead change rather than follow it. From AI integration to next-gen digital ecosystems, we're always at the frontier of what's possible.",
  },
  {
    n: "05",
    title: "Integrity",
    desc: "Transparency, accountability, and trust are non-negotiable. We say what we mean, deliver what we promise, and stand behind every solution we provide.",
  },
  {
    n: "06",
    title: "Partnership",
    desc: "We align with your vision and become an extension of your team. Your goals are our goals — your success is our most important metric.",
  },
];

export default function Values() {
  return (
    <section id="values" className="mx-auto max-w-7xl px-6 py-28 md:px-10">
      <Reveal>
        <Eyebrow index="02" label="Our Values" />
        <h2 className="mt-5 font-display text-5xl leading-[0.95] text-fog md:text-6xl">
          What We Stand For
        </h2>
        <p className="mt-6 max-w-xl text-[14.5px] leading-relaxed text-fog-dim">
          These aren&apos;t slogans — they&apos;re the operating principles that guide every
          decision, every partnership, and every solution we deliver.
        </p>
      </Reveal>

      <div className="mt-16 divide-y divide-wire border-t border-wire">
        {VALUES.map((v, i) => (
          <Reveal
            key={v.n}
            delay={i * 0.05}
            className="group grid grid-cols-[auto_1fr] items-baseline gap-6 py-7 transition-colors md:grid-cols-[80px_260px_1fr] md:gap-10"
          >
            <span className="font-mono text-[13px] text-signal-soft">{v.n}</span>
            <h3 className="text-[19px] font-medium text-fog">{v.title}</h3>
            <p className="max-w-xl text-[13.5px] leading-relaxed text-fog-dim">{v.desc}</p>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
