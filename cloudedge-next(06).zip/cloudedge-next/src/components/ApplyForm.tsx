"use client";

import { useState } from "react";
import { Send, Check } from "lucide-react";

export default function ApplyForm({ jobSlug, jobTitle }: { jobSlug: string; jobTitle: string }) {
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (sent) {
    return (
      <div className="flex items-center gap-3 rounded-lg border border-signal/30 bg-signal/10 px-4 py-4 text-[13.5px] text-signal-soft">
        <Check size={16} /> Application received — we&apos;ll be in touch.
      </div>
    );
  }

  return (
    <form
      className="flex flex-col gap-5"
      onSubmit={async (e) => {
        e.preventDefault();
        setError(null);
        setLoading(true);
        const form = e.currentTarget;
        const data = new FormData(form);
        try {
          const res = await fetch("/api/careers", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              jobSlug,
              jobTitle,
              name: data.get("name"),
              email: data.get("email"),
              phone: data.get("phone"),
              linkedin: data.get("linkedin"),
              message: data.get("message"),
            }),
          });
          const json = await res.json();
          if (!res.ok || !json.success) {
            setError(json.message || "Something went wrong. Please try again.");
            return;
          }
          setSent(true);
        } catch {
          setError("Network error — please try again.");
        } finally {
          setLoading(false);
        }
      }}
    >
      {error && (
        <div className="rounded-lg border border-red-400/30 bg-red-400/10 px-4 py-3 text-[13px] text-red-500">
          {error}
        </div>
      )}
      <div className="grid gap-5 sm:grid-cols-2">
        <label className="flex flex-col gap-2">
          <span className="font-mono text-[11px] uppercase tracking-wide text-fog-dimmer">
            Full Name *
          </span>
          <input type="text" name="name" required placeholder="Jane Doe" className="field" />
        </label>
        <label className="flex flex-col gap-2">
          <span className="font-mono text-[11px] uppercase tracking-wide text-fog-dimmer">
            Email *
          </span>
          <input
            type="email"
            name="email"
            required
            placeholder="jane@email.com"
            className="field"
          />
        </label>
      </div>
      <div className="grid gap-5 sm:grid-cols-2">
        <label className="flex flex-col gap-2">
          <span className="font-mono text-[11px] uppercase tracking-wide text-fog-dimmer">
            Phone
          </span>
          <input type="tel" name="phone" placeholder="+1 (555) 000-0000" className="field" />
        </label>
        <label className="flex flex-col gap-2">
          <span className="font-mono text-[11px] uppercase tracking-wide text-fog-dimmer">
            LinkedIn / Portfolio
          </span>
          <input type="url" name="linkedin" placeholder="https://" className="field" />
        </label>
      </div>
      <label className="flex flex-col gap-2">
        <span className="font-mono text-[11px] uppercase tracking-wide text-fog-dimmer">
          Why are you a fit? *
        </span>
        <textarea
          name="message"
          required
          rows={4}
          placeholder="Tell us a bit about your background and why this role interests you…"
          className="field resize-none"
        />
      </label>
      <button
        type="submit"
        disabled={loading}
        className="mt-1 inline-flex w-fit items-center gap-2 rounded-full bg-signal px-6 py-3 font-mono text-[13px] font-medium text-white transition-transform hover:scale-[1.03] disabled:opacity-60 disabled:hover:scale-100"
      >
        {loading ? "Submitting…" : "Submit Application"}
        <Send size={14} />
      </button>

      <style jsx global>{`
        .field {
          width: 100%;
          background: var(--void);
          border: 1px solid var(--wire-light);
          border-radius: 8px;
          padding: 10px 14px;
          font-size: 13.5px;
          color: var(--fog);
          font-family: "DM Sans", sans-serif;
        }
        .field::placeholder {
          color: var(--fog-dimmer);
        }
        .field:focus {
          outline: none;
          border-color: var(--signal);
        }
      `}</style>
    </form>
  );
}
