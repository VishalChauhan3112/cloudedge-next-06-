const DEFAULT_ITEMS = [
  "Backup & Recovery",
  "IT Consulting",
  "Cloud Infrastructure",
  "Cybersecurity Solutions",
  "Managed IT Services",
];

export default function StatusStrip({
  items = DEFAULT_ITEMS,
  separator = "dot",
}: {
  items?: string[];
  separator?: "dot" | "star";
}) {
  const loop = [...items, ...items];

  return (
    <div className="relative overflow-hidden border-y border-wire bg-panel py-4">
      <div className="flex w-max animate-[marquee_28s_linear_infinite] gap-0">
        {[0, 1].map((set) => (
          <div key={set} className="flex shrink-0 items-center">
            {loop.map((item, i) => (
              <span
                key={`${set}-${i}`}
                className="flex items-center gap-3 px-6 font-mono text-[12px] uppercase tracking-[0.14em] text-fog-dim"
              >
                {separator === "star" ? (
                  <span className="text-signal">✦</span>
                ) : (
                  <span className="h-1.5 w-1.5 rounded-full bg-signal" />
                )}
                {item}
              </span>
            ))}
          </div>
        ))}
      </div>
      <style>{`
        @keyframes marquee {
          from { transform: translateX(0); }
          to { transform: translateX(-50%); }
        }
      `}</style>
    </div>
  );
}
