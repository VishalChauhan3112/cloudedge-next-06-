"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Menu, X, Search } from "lucide-react";

const LINKS = [
  { href: "/#services", label: "Services" },
  { href: "/about", label: "About" },
  { href: "/case-studies", label: "Case Studies" },
  { href: "/blog", label: "Blog" },
  { href: "/careers", label: "Careers" },
  { href: "/#contact", label: "Contact" },
];

export default function Nav() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <nav
      className={`fixed top-0 z-50 w-full transition-colors duration-300 ${
        scrolled ? "bg-void/85 backdrop-blur-md border-b border-wire" : "bg-transparent"
      }`}
    >
      <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4 md:px-10">
        <Link href="/" className="font-display text-2xl tracking-wide text-fog">
          CLOUD<span className="text-signal">edge</span>
        </Link>

        <ul className="hidden items-center gap-8 md:flex">
          {LINKS.map((l) => (
            <li key={l.href}>
              <Link
                href={l.href}
                className="font-mono text-[12px] tracking-wide text-fog-dim transition-colors hover:text-fog"
              >
                {l.label}
              </Link>
            </li>
          ))}
        </ul>

        <div className="hidden items-center gap-4 md:flex">
          <Link
            href="/search"
            aria-label="Search"
            className="text-fog-dim transition-colors hover:text-fog"
          >
            <Search size={16} />
          </Link>
          <Link
            href="/schedule"
            className="rounded-full border border-signal/50 px-5 py-2 font-mono text-[12px] tracking-wide text-signal-soft transition-colors hover:bg-signal hover:text-white"
          >
            Schedule A Call
          </Link>
        </div>

        <button
          className="text-fog md:hidden"
          onClick={() => setOpen((o) => !o)}
          aria-label="Toggle menu"
        >
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {open && (
        <div className="border-t border-wire bg-void px-6 pb-6 md:hidden">
          <ul className="flex flex-col gap-4 pt-4">
            {LINKS.map((l) => (
              <li key={l.href}>
                <Link
                  href={l.href}
                  onClick={() => setOpen(false)}
                  className="font-mono text-sm text-fog-dim hover:text-fog"
                >
                  {l.label}
                </Link>
              </li>
            ))}
            <li>
              <Link
                href="/search"
                onClick={() => setOpen(false)}
                className="font-mono text-sm text-fog-dim hover:text-fog"
              >
                Search
              </Link>
            </li>
            <li>
              <Link
                href="/schedule"
                onClick={() => setOpen(false)}
                className="mt-2 inline-block rounded-full border border-signal/50 px-5 py-2 font-mono text-[12px] text-signal-soft"
              >
                Schedule A Call
              </Link>
            </li>
          </ul>
        </div>
      )}
    </nav>
  );
}
