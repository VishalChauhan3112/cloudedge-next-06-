"use client";

import { useMemo, useState } from "react";
import { ChevronLeft, ChevronRight, Check, Video, Clock, Calendar as CalendarIcon } from "lucide-react";

const TIME_SLOTS = [
  "09:00",
  "09:30",
  "10:00",
  "10:30",
  "11:00",
  "11:30",
  "12:00",
  "12:30",
  "13:00",
  "13:30",
  "14:00",
  "14:30",
  "15:00",
  "15:30",
  "16:00",
  "16:30",
  "17:00",
];

const DAY_LABELS = ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"];
const MONTHS = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];

function toISODate(d: Date) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function formatSlot(t: string) {
  const [h, m] = t.split(":").map(Number);
  const period = h >= 12 ? "pm" : "am";
  const hour12 = h % 12 === 0 ? 12 : h % 12;
  return `${hour12}:${String(m).padStart(2, "0")}${period}`;
}

export default function ScheduleForm() {
  const today = useMemo(() => {
    const t = new Date();
    t.setHours(0, 0, 0, 0);
    return t;
  }, []);

  const [viewDate, setViewDate] = useState(new Date(today.getFullYear(), today.getMonth(), 1));
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [fullName, setFullName] = useState("");
  const [mobile, setMobile] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [booked, setBooked] = useState<{ name: string; mobile: string; when: string } | null>(
    null
  );

  const days = useMemo(() => {
    const year = viewDate.getFullYear();
    const month = viewDate.getMonth();
    const firstDay = new Date(year, month, 1);
    const startOffset = (firstDay.getDay() + 6) % 7; // shift so Monday = 0
    const daysInMonth = new Date(year, month + 1, 0).getDate();

    const cells: { date: Date | null; disabled: boolean }[] = [];
    for (let i = 0; i < startOffset; i++) cells.push({ date: null, disabled: true });
    for (let d = 1; d <= daysInMonth; d++) {
      const date = new Date(year, month, d);
      const isWeekend = date.getDay() === 0 || date.getDay() === 6;
      const isPast = date < today;
      cells.push({ date, disabled: isWeekend || isPast });
    }
    return cells;
  }, [viewDate, today]);

  if (booked) {
    return (
      <div className="mx-auto max-w-lg rounded-2xl border border-wire bg-panel p-10 text-center shadow-[0_2px_16px_rgba(23,21,31,0.05)]">
        <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-signal/10 text-signal">
          <Check size={26} />
        </div>
        <h2 className="mt-6 font-display text-3xl text-fog">You&apos;re Booked!</h2>
        <p className="mt-3 text-[14.5px] leading-relaxed text-fog-dim">
          Hi {booked.name}, your call has been scheduled for <strong className="text-fog">{booked.when}</strong>.
          We&apos;ll reach out to {booked.mobile} to confirm the meeting details.
        </p>
        <button
          type="button"
          onClick={() => {
            setBooked(null);
            setSelectedDate(null);
            setSelectedTime(null);
            setFullName("");
            setMobile("");
          }}
          className="mt-8 inline-flex items-center gap-2 rounded-full bg-signal px-6 py-3 font-mono text-[13px] font-medium text-white transition-transform hover:scale-[1.03]"
        >
          Schedule Another Call
        </button>
      </div>
    );
  }

  return (
    <div className="grid gap-8 rounded-2xl border border-wire bg-panel p-6 shadow-[0_2px_16px_rgba(23,21,31,0.05)] md:grid-cols-[1fr_1.1fr] md:p-8">
      {/* Calendar */}
      <div>
        <div className="flex items-center justify-between">
          <h3 className="text-[15px] font-medium text-fog">
            {MONTHS[viewDate.getMonth()]} {viewDate.getFullYear()}
          </h3>
          <div className="flex gap-1.5">
            <button
              type="button"
              aria-label="Previous month"
              onClick={() => setViewDate(new Date(viewDate.getFullYear(), viewDate.getMonth() - 1, 1))}
              className="flex h-8 w-8 items-center justify-center rounded-full border border-wire-light text-fog-dim hover:border-signal hover:text-signal-soft"
            >
              <ChevronLeft size={14} />
            </button>
            <button
              type="button"
              aria-label="Next month"
              onClick={() => setViewDate(new Date(viewDate.getFullYear(), viewDate.getMonth() + 1, 1))}
              className="flex h-8 w-8 items-center justify-center rounded-full border border-wire-light text-fog-dim hover:border-signal hover:text-signal-soft"
            >
              <ChevronRight size={14} />
            </button>
          </div>
        </div>

        <div className="mt-5 grid grid-cols-7 gap-1 text-center">
          {DAY_LABELS.map((d) => (
            <span key={d} className="font-mono text-[10px] text-fog-dimmer">
              {d}
            </span>
          ))}
          {days.map((cell, i) => {
            if (!cell.date) return <span key={i} />;
            const isSelected = selectedDate && toISODate(cell.date) === toISODate(selectedDate);
            return (
              <button
                key={i}
                type="button"
                disabled={cell.disabled}
                onClick={() => {
                  setSelectedDate(cell.date);
                  setSelectedTime(null);
                }}
                className={`aspect-square rounded-lg text-[12.5px] transition-colors ${
                  cell.disabled
                    ? "text-fog-dimmer/50"
                    : isSelected
                      ? "bg-signal text-white"
                      : "text-fog hover:bg-panel-hover"
                }`}
              >
                {cell.date.getDate()}
              </button>
            );
          })}
        </div>

        <div className="mt-6 flex flex-col gap-2 border-t border-wire pt-5 font-mono text-[11px] text-fog-dimmer">
          <span className="flex items-center gap-2">
            <Clock size={12} /> 30 min
          </span>
          <span className="flex items-center gap-2">
            <Video size={12} /> Google Meet / Zoom
          </span>
          <span className="flex items-center gap-2">
            <CalendarIcon size={12} /> Mon – Fri, 9 AM – 5 PM
          </span>
        </div>
      </div>

      {/* Time slots + details */}
      <div className="border-t border-wire pt-6 md:border-l md:border-t-0 md:pl-8 md:pt-0">
        {!selectedDate ? (
          <div className="flex h-full flex-col items-center justify-center text-center text-fog-dim">
            <ChevronLeft size={20} className="mb-2 text-fog-dimmer" />
            <p className="text-[13.5px]">Pick a date on the calendar</p>
            <p className="text-[13.5px]">to see available times</p>
          </div>
        ) : !selectedTime ? (
          <>
            <h3 className="text-[15px] font-medium text-fog">
              {selectedDate.toLocaleDateString("en-US", {
                weekday: "long",
                month: "long",
                day: "numeric",
              })}
            </h3>
            <div className="mt-5 grid max-h-72 grid-cols-2 gap-2 overflow-y-auto pr-1">
              {TIME_SLOTS.map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setSelectedTime(t)}
                  className="rounded-lg border border-wire-light py-2.5 text-[13px] text-fog transition-colors hover:border-signal hover:text-signal-soft"
                >
                  {formatSlot(t)}
                </button>
              ))}
            </div>
          </>
        ) : (
          <form
            className="flex flex-col gap-5"
            onSubmit={async (e) => {
              e.preventDefault();
              setError(null);
              setLoading(true);
              try {
                const res = await fetch("/api/schedule", {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify({
                    date: toISODate(selectedDate),
                    time: selectedTime,
                    fullName,
                    mobile,
                  }),
                });
                const json = await res.json();
                if (!res.ok || !json.success) {
                  setError(json.message || "Something went wrong. Please try again.");
                  return;
                }
                setBooked({ name: fullName, mobile, when: json.message });
              } catch {
                setError("Network error — please try again.");
              } finally {
                setLoading(false);
              }
            }}
          >
            <div>
              <h3 className="text-[15px] font-medium text-fog">Your Details</h3>
              <p className="mt-1 text-[13px] text-fog-dim">Almost done! Just a couple more details.</p>
            </div>

            <div className="rounded-lg border border-wire-light bg-void px-4 py-3 text-[13px] text-fog-dim">
              {selectedDate.toLocaleDateString("en-US", {
                weekday: "long",
                month: "long",
                day: "numeric",
              })}{" "}
              at <span className="text-fog">{formatSlot(selectedTime)}</span>
            </div>

            {error && (
              <div className="rounded-lg border border-red-400/30 bg-red-400/10 px-4 py-3 text-[13px] text-red-500">
                {error}
              </div>
            )}

            <label className="flex flex-col gap-2">
              <span className="font-mono text-[11px] uppercase tracking-wide text-fog-dimmer">
                Full Name *
              </span>
              <input
                type="text"
                required
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="John Smith"
                className="field"
              />
            </label>
            <label className="flex flex-col gap-2">
              <span className="font-mono text-[11px] uppercase tracking-wide text-fog-dimmer">
                Mobile Number *
              </span>
              <input
                type="tel"
                required
                value={mobile}
                onChange={(e) => setMobile(e.target.value)}
                placeholder="+1 (555) 000-0000"
                className="field"
              />
            </label>

            <div className="mt-1 flex gap-3">
              <button
                type="button"
                onClick={() => setSelectedTime(null)}
                className="rounded-full border border-wire-light px-6 py-3 font-mono text-[13px] text-fog-dim transition-colors hover:border-signal/60 hover:text-signal-soft"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={loading}
                className="flex-1 rounded-full bg-signal px-6 py-3 font-mono text-[13px] font-medium text-white transition-transform hover:scale-[1.02] disabled:opacity-60 disabled:hover:scale-100"
              >
                {loading ? "Booking…" : "Book Call"}
              </button>
            </div>
          </form>
        )}
      </div>

      <style jsx global>{`
        .field {
          width: 100%;
          background: var(--void);
          border: 1px solid var(--wire-light);
          border-radius: 8px;
          padding: 10px 14px;
          font-size: 13.5px;
          color: var(--fog);
          font-family: "DM Sans", sans-serif;
        }
        .field::placeholder {
          color: var(--fog-dimmer);
        }
        .field:focus {
          outline: none;
          border-color: var(--signal);
        }
      `}</style>
    </div>
  );
}
