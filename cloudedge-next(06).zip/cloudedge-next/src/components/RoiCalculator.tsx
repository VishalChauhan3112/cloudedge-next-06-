"use client";

import { useMemo, useState } from "react";
import { Info } from "lucide-react";

function Slider({
  label,
  value,
  onChange,
  min,
  max,
  step,
  format,
}: {
  label: string;
  value: number;
  onChange: (v: number) => void;
  min: number;
  max: number;
  step: number;
  format: (v: number) => string;
}) {
  return (
    <div>
      <div className="flex items-baseline justify-between">
        <label className="text-[13.5px] text-fog">{label}</label>
        <span className="font-mono text-[13px] text-signal-soft">{format(value)}</span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="mt-3 w-full accent-signal"
      />
    </div>
  );
}

export default function RoiCalculator() {
  const [employees, setEmployees] = useState(50);
  const [avgHourlyCost, setAvgHourlyCost] = useState(35);
  const [downtimeHours, setDowntimeHours] = useState(6);
  const [currentItSpend, setCurrentItSpend] = useState(3000);
  const [downtimeReduction, setDowntimeReduction] = useState(60);

  const results = useMemo(() => {
    const affectedShare = 0.4; // rough share of staff typically blocked by an IT outage
    const monthlyDowntimeCost = employees * affectedShare * avgHourlyCost * downtimeHours;
    const projectedDowntimeHours = downtimeHours * (1 - downtimeReduction / 100);
    const projectedDowntimeCost = employees * affectedShare * avgHourlyCost * projectedDowntimeHours;
    const downtimeSavings = monthlyDowntimeCost - projectedDowntimeCost;
    const annualDowntimeSavings = downtimeSavings * 12;

    return {
      monthlyDowntimeCost,
      projectedDowntimeCost,
      downtimeSavings,
      annualDowntimeSavings,
    };
  }, [employees, avgHourlyCost, downtimeHours, downtimeReduction]);

  const fmt = (n: number) =>
    n.toLocaleString("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 });

  return (
    <div className="grid gap-8 rounded-2xl border border-wire bg-panel p-6 shadow-[0_2px_16px_rgba(23,21,31,0.05)] md:grid-cols-2 md:p-10">
      <div className="flex flex-col gap-8">
        <Slider
          label="Employees affected by IT issues"
          value={employees}
          onChange={setEmployees}
          min={5}
          max={500}
          step={5}
          format={(v) => `${v}`}
        />
        <Slider
          label="Average fully-loaded hourly cost"
          value={avgHourlyCost}
          onChange={setAvgHourlyCost}
          min={15}
          max={100}
          step={1}
          format={(v) => `$${v}/hr`}
        />
        <Slider
          label="Downtime hours per month (current)"
          value={downtimeHours}
          onChange={setDowntimeHours}
          min={0}
          max={40}
          step={1}
          format={(v) => `${v} hrs`}
        />
        <Slider
          label="Current monthly IT spend"
          value={currentItSpend}
          onChange={setCurrentItSpend}
          min={0}
          max={20000}
          step={100}
          format={(v) => fmt(v)}
        />
        <Slider
          label="Assumed downtime reduction with managed IT"
          value={downtimeReduction}
          onChange={setDowntimeReduction}
          min={0}
          max={90}
          step={5}
          format={(v) => `${v}%`}
        />
      </div>

      <div className="flex flex-col justify-center gap-6 border-t border-wire pt-8 md:border-l md:border-t-0 md:pl-10 md:pt-0">
        <div>
          <div className="font-mono text-[11px] uppercase tracking-wide text-fog-dimmer">
            Estimated Downtime Cost Today
          </div>
          <div className="mt-1 font-display text-4xl text-fog">
            {fmt(results.monthlyDowntimeCost)}
            <span className="text-[15px] font-normal text-fog-dim"> /mo</span>
          </div>
        </div>
        <div>
          <div className="font-mono text-[11px] uppercase tracking-wide text-fog-dimmer">
            Estimated Cost With Managed IT
          </div>
          <div className="mt-1 font-display text-4xl text-fog">
            {fmt(results.projectedDowntimeCost)}
            <span className="text-[15px] font-normal text-fog-dim"> /mo</span>
          </div>
        </div>
        <div className="rounded-xl border border-signal/30 bg-signal/10 p-5">
          <div className="font-mono text-[11px] uppercase tracking-wide text-signal-soft">
            Potential Annual Savings
          </div>
          <div className="mt-1 font-display text-5xl text-signal-deep">
            {fmt(results.annualDowntimeSavings)}
          </div>
          <p className="mt-2 text-[12px] leading-relaxed text-fog-dim">
            Based on downtime cost reduction alone — doesn&apos;t include potential savings
            from consolidating your current {fmt(currentItSpend)}/mo IT spend.
          </p>
        </div>
      </div>

      <div className="flex items-start gap-2.5 rounded-lg bg-void px-4 py-3 text-[12px] leading-relaxed text-fog-dimmer md:col-span-2">
        <Info size={14} className="mt-0.5 shrink-0" />
        This is a rough estimate based on the assumptions above, meant to illustrate how
        downtime costs scale — not a quote or guarantee. Actual results depend on your specific
        environment. Talk to us for a real assessment.
      </div>
    </div>
  );
}
