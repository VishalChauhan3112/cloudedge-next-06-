"use client";

import { useState } from "react";
import { ArrowRight } from "lucide-react";

function LinkedinIcon() {
  return (
    <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor">
      <path d="M20.45 20.45h-3.55v-5.57c0-1.33-.02-3.04-1.85-3.04-1.85 0-2.14 1.45-2.14 2.94v5.67H9.36V9h3.41v1.56h.05c.47-.9 1.63-1.85 3.36-1.85 3.6 0 4.27 2.37 4.27 5.45v6.29zM5.34 7.43a2.06 2.06 0 1 1 0-4.12 2.06 2.06 0 0 1 0 4.12zM7.12 20.45H3.56V9h3.56v11.45z" />
    </svg>
  );
}
function TwitterIcon() {
  return (
    <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor">
      <path d="M18.24 2H21l-6.55 7.49L22.2 22h-6.32l-4.95-6.47L5.24 22H2.46l7.01-8.02L2 2h6.47l4.47 5.9L18.24 2zm-1.1 18.17h1.76L7.9 3.73H6l11.14 16.44z" />
    </svg>
  );
}
function FacebookIcon() {
  return (
    <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor">
      <path d="M13.5 21v-7.9h2.65l.4-3.08H13.5V8.06c0-.89.25-1.5 1.52-1.5h1.63V3.85A21.8 21.8 0 0 0 14.3 3.7c-2.35 0-3.96 1.43-3.96 4.06v2.26H7.68v3.08h2.66V21h3.16z" />
    </svg>
  );
}

export default function Footer() {
  const [subscribed, setSubscribed] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  return (
    <footer className="border-t border-wire">
      <div className="mx-auto max-w-7xl px-6 pt-16 md:px-10">
        <div className="flex flex-col items-center justify-between gap-6 border-b border-wire pb-14 text-center md:flex-row md:text-left">
          <h3 className="font-display text-3xl text-fog md:text-4xl">
            Join Our Newsletter Today
          </h3>
          {subscribed ? (
            <span className="text-[13.5px] text-signal-soft">Subscribed — thanks!</span>
          ) : (
            <div className="flex w-full max-w-sm flex-col gap-2">
              <form
                className="flex w-full items-center gap-2 rounded-full border border-wire-light bg-void p-1.5"
                onSubmit={async (e) => {
                  e.preventDefault();
                  setError(null);
                  setLoading(true);
                  const form = e.currentTarget;
                  const email = new FormData(form).get("email");
                  try {
                    const res = await fetch("/api/newsletter", {
                      method: "POST",
                      headers: { "Content-Type": "application/json" },
                      body: JSON.stringify({ email }),
                    });
                    const json = await res.json();
                    if (!res.ok || !json.success) {
                      setError(json.message || "Something went wrong.");
                      return;
                    }
                    setSubscribed(true);
                  } catch {
                    setError("Network error — please try again.");
                  } finally {
                    setLoading(false);
                  }
                }}
              >
                <input
                  type="email"
                  name="email"
                  required
                  placeholder="Your email address"
                  className="w-full bg-transparent px-4 py-2 text-[13.5px] text-fog placeholder:text-fog-dimmer focus:outline-none"
                />
                <button
                  type="submit"
                  disabled={loading}
                  className="flex shrink-0 items-center gap-1.5 rounded-full bg-signal px-5 py-2.5 font-mono text-[12px] font-medium text-white transition-transform hover:scale-[1.03] disabled:opacity-60 disabled:hover:scale-100"
                >
                  {loading ? "Sending…" : "Subscribe"} <ArrowRight size={13} />
                </button>
              </form>
              {error && <span className="text-[12px] text-red-500">{error}</span>}
            </div>
          )}
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-6 py-16 md:px-10">
        <div className="flex flex-col justify-between gap-10 md:flex-row">
          <div className="max-w-sm">
            <a href="/" className="font-display text-2xl tracking-wide text-fog">
              CLOUD<span className="text-signal">edge</span>
            </a>
            <p className="mt-4 text-[13.5px] leading-relaxed text-fog-dim">
              Leading managed service provider delivering innovative IT solutions for modern
              businesses that want to scale with confidence.
            </p>
            <div className="mt-6 flex gap-3">
              {[LinkedinIcon, TwitterIcon, FacebookIcon].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  className="flex h-9 w-9 items-center justify-center rounded-full border border-wire-light text-fog-dim transition-colors hover:border-signal hover:text-signal-soft"
                >
                  <Icon />
                </a>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-10 sm:gap-16">
            <div>
              <h5 className="font-mono text-[11px] uppercase tracking-wide text-fog-dimmer">
                Company
              </h5>
              <ul className="mt-4 flex flex-col gap-3">
                {[
                  { label: "About", href: "/about" },
                  { label: "Services", href: "/#services" },
                  { label: "Pricing", href: "/#pricing" },
                  { label: "Careers", href: "/careers" },
                  { label: "Contact", href: "/#contact" },
                  { label: "Schedule a Call", href: "/schedule" },
                ].map((l) => (
                  <li key={l.label}>
                    <a href={l.href} className="text-[13.5px] text-fog-dim hover:text-fog">
                      {l.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h5 className="font-mono text-[11px] uppercase tracking-wide text-fog-dimmer">
                Resources
              </h5>
              <ul className="mt-4 flex flex-col gap-3">
                {[
                  { label: "Blog", href: "/blog" },
                  { label: "Case Studies", href: "/case-studies" },
                  { label: "Guides & Checklists", href: "/resources" },
                  { label: "Downtime Cost Calculator", href: "/roi-calculator" },
                  { label: "System Status", href: "/status" },
                ].map((l) => (
                  <li key={l.label}>
                    <a href={l.href} className="text-[13.5px] text-fog-dim hover:text-fog">
                      {l.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        <div className="mt-14 flex flex-col-reverse items-center justify-between gap-4 border-t border-wire pt-8 sm:flex-row">
          <p className="font-mono text-[11px] text-fog-dimmer">
            © 2026 CloudEdge Tech Services. All rights reserved.
          </p>
          <div className="flex gap-6 font-mono text-[11px] text-fog-dimmer">
            <a href="#" className="hover:text-fog">
              Privacy Policy
            </a>
            <a href="#" className="hover:text-fog">
              Terms of Service
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
