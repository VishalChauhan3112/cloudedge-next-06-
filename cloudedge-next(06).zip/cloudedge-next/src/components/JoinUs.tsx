import { Rocket, Lightbulb, GraduationCap, Network, ArrowRight } from "lucide-react";
import Reveal from "./Reveal";
import Eyebrow from "./Eyebrow";

const FEATURES = [
  { icon: Rocket, label: "Career Growth" },
  { icon: Lightbulb, label: "Innovation Culture" },
  { icon: GraduationCap, label: "Strong Mentorship" },
  { icon: Network, label: "Real-Time Projects" },
];

export default function JoinUs() {
  return (
    <section id="joinus" className="relative overflow-hidden border-y border-wire bg-panel/40">
      <div
        className="pointer-events-none absolute inset-0 opacity-20"
        style={{
          backgroundImage:
            "linear-gradient(to right, var(--wire) 1px, transparent 1px), linear-gradient(to bottom, var(--wire) 1px, transparent 1px)",
          backgroundSize: "48px 48px",
        }}
      />
      <div className="relative mx-auto max-w-4xl px-6 py-28 text-center md:px-10">
        <Reveal className="flex justify-center">
          <Eyebrow index="05" label="Careers" />
        </Reveal>
        <Reveal delay={0.05}>
          <h2 className="mt-5 font-display text-6xl text-fog md:text-7xl">Join Us</h2>
        </Reveal>
        <Reveal delay={0.1}>
          <p className="mx-auto mt-8 max-w-2xl text-[14.5px] leading-relaxed text-fog-dim">
            At CloudEdge Tech Services, we don&apos;t just offer jobs — we create opportunities
            to shape your future. Whether you are a fresher ready to begin your career journey or
            an experienced professional aiming for new heights, we provide a platform that
            matches your ambition and talent.
          </p>
        </Reveal>

        <Reveal delay={0.15} className="mt-12 flex flex-wrap justify-center gap-4">
          {FEATURES.map((f) => {
            const Icon = f.icon;
            return (
              <div
                key={f.label}
                className="flex items-center gap-2.5 rounded-full border border-wire-light bg-panel px-5 py-2.5"
              >
                <Icon size={15} className="text-signal-soft" />
                <span className="text-[13px] text-fog">{f.label}</span>
              </div>
            );
          })}
        </Reveal>

        <Reveal delay={0.2}>
          <a
            href="/careers"
            className="group mt-12 inline-flex items-center gap-2 rounded-full bg-signal px-8 py-4 font-mono text-[13px] font-medium tracking-wide text-void transition-transform hover:scale-[1.03]"
          >
            View Open Positions
            <ArrowRight size={15} className="transition-transform group-hover:translate-x-0.5" />
          </a>
        </Reveal>
      </div>
    </section>
  );
}
