"use client";

/**
 * PLACEHOLDER CONTENT — names/quotes below are illustrative examples for layout
 * purposes, not real CloudEdge clients. Replace `TESTIMONIALS` with real quotes
 * (with permission) before publishing.
 */

import { useState } from "react";
import { Star, ChevronLeft, ChevronRight, Quote } from "lucide-react";
import Reveal from "./Reveal";
import Eyebrow from "./Eyebrow";

const TESTIMONIALS = [
  {
    quote:
      "Our infrastructure moved to CloudEdge's managed stack with zero downtime. Response times on tickets are the fastest we've had from any provider.",
    name: "Example Client",
    role: "Operations Lead, SaaS Startup",
  },
  {
    quote:
      "They scoped our security review clearly, flagged real gaps, and fixed them without the usual upsell pressure. Refreshingly direct team.",
    name: "Example Client",
    role: "Founder, Fintech SMB",
  },
  {
    quote:
      "The staffing team placed two senior engineers within three weeks who were genuinely strong fits for our stack and culture.",
    name: "Example Client",
    role: "Engineering Manager, Enterprise",
  },
];

export default function Testimonials() {
  const [i, setI] = useState(0);
  const t = TESTIMONIALS[i];

  return (
    <section className="border-y border-wire bg-panel/60">
      <div className="mx-auto max-w-4xl px-6 py-28 text-center md:px-10">
        <Reveal className="flex flex-col items-center">
          <Eyebrow index="04" label="Testimonials" />
          <h2 className="mt-5 font-display text-5xl leading-[0.95] text-fog md:text-6xl">
            Real Stories From Our Clients
          </h2>
        </Reveal>

        <Reveal delay={0.1} className="mt-14">
          <Quote className="mx-auto text-signal/40" size={32} strokeWidth={1.5} />
          <p className="mx-auto mt-6 max-w-2xl text-[19px] leading-relaxed text-fog md:text-[22px]">
            &ldquo;{t.quote}&rdquo;
          </p>

          <div className="mt-8 flex items-center justify-center gap-1 text-signal">
            {Array.from({ length: 5 }).map((_, idx) => (
              <Star key={idx} size={14} fill="currentColor" strokeWidth={0} />
            ))}
          </div>

          <div className="mt-4">
            <div className="text-[14px] font-medium text-fog">{t.name}</div>
            <div className="font-mono text-[11px] text-fog-dimmer">{t.role}</div>
          </div>

          <div className="mt-10 flex items-center justify-center gap-3">
            <button
              type="button"
              onClick={() => setI((i - 1 + TESTIMONIALS.length) % TESTIMONIALS.length)}
              aria-label="Previous testimonial"
              className="flex h-10 w-10 items-center justify-center rounded-full border border-wire-light text-fog-dim transition-colors hover:border-signal hover:text-signal-soft"
            >
              <ChevronLeft size={16} />
            </button>
            <div className="flex gap-1.5">
              {TESTIMONIALS.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => setI(idx)}
                  aria-label={`Go to testimonial ${idx + 1}`}
                  className={`h-1.5 rounded-full transition-all ${
                    idx === i ? "w-6 bg-signal" : "w-1.5 bg-wire-light"
                  }`}
                />
              ))}
            </div>
            <button
              type="button"
              onClick={() => setI((i + 1) % TESTIMONIALS.length)}
              aria-label="Next testimonial"
              className="flex h-10 w-10 items-center justify-center rounded-full border border-wire-light text-fog-dim transition-colors hover:border-signal hover:text-signal-soft"
            >
              <ChevronRight size={16} />
            </button>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
