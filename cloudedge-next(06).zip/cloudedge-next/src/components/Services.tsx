import Link from "next/link";
import { ArrowRight } from "lucide-react";
import Reveal from "./Reveal";
import Eyebrow from "./Eyebrow";
import ServiceIcon from "./ServiceIcon";
import { SERVICES } from "@/lib/services";

export default function Services() {
  return (
    <section id="services" className="mx-auto max-w-7xl px-6 py-28 md:px-10">
      <Reveal>
        <Eyebrow index="01" label="What We Offer" />
        <div className="mt-5 flex flex-col justify-between gap-6 md:flex-row md:items-end">
          <h2 className="font-display text-5xl leading-[0.95] text-fog md:text-6xl">
            Comprehensive
            <br />
            IT Solutions
          </h2>
          <p className="max-w-xs text-[14px] leading-relaxed text-fog-dim">
            CloudEdge delivers practical, high-impact solutions tailored for today&apos;s
            business and technology needs.
          </p>
        </div>
      </Reveal>

      <div className="mt-16 border-t border-wire">
        {SERVICES.map((s, i) => (
          <Reveal key={s.slug} delay={Math.min(i * 0.04, 0.24)}>
            <Link
              href={`/services/${s.slug}`}
              className="group grid grid-cols-[56px_1fr_auto] items-center gap-6 border-b border-wire py-7 transition-colors hover:bg-panel-hover md:grid-cols-[80px_200px_1fr_auto] md:gap-10 md:px-4"
            >
              <span className="font-mono text-[13px] text-signal-soft">/ {s.n}</span>
              <div className="hidden h-11 w-11 items-center justify-center rounded-lg border border-wire-light text-signal-soft transition-colors group-hover:border-signal group-hover:text-signal md:flex">
                <ServiceIcon name={s.icon} />
              </div>
              <div>
                <h3 className="text-[19px] font-medium text-fog md:text-[22px]">{s.title}</h3>
                <p className="mt-1.5 max-w-lg text-[13.5px] leading-relaxed text-fog-dim">
                  {s.summary}
                </p>
              </div>
              <ArrowRight
                size={20}
                className="hidden shrink-0 -translate-x-1 text-fog-dimmer opacity-0 transition-all duration-300 group-hover:translate-x-0 group-hover:text-signal group-hover:opacity-100 md:block"
              />
            </Link>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
