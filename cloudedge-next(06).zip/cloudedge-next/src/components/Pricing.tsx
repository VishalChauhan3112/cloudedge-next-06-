"use client";

/**
 * PLACEHOLDER CONTENT — pricing tiers/figures below are illustrative examples
 * (styled after typical MSP engagement tiers), not confirmed CloudEdge pricing.
 * Replace `PLANS` with real numbers before publishing.
 */

import { Check } from "lucide-react";
import Reveal from "./Reveal";
import Eyebrow from "./Eyebrow";

const PLANS = [
  {
    name: "Starter",
    price: "$900",
    period: "/mo",
    desc: "For small teams needing core IT support and monitoring.",
    features: [
      "Managed IT helpdesk",
      "Cloud infrastructure monitoring",
      "Monthly security review",
      "Business-hours support",
    ],
    featured: false,
  },
  {
    name: "Growth",
    price: "$2,400",
    period: "/mo",
    desc: "For scaling businesses that need proactive coverage.",
    features: [
      "Everything in Starter",
      "24/7 monitoring & response",
      "Cybersecurity & backup management",
      "Dedicated account lead",
      "Quarterly strategy review",
    ],
    featured: true,
  },
  {
    name: "Enterprise",
    price: "Custom",
    period: "",
    desc: "For organizations with complex, multi-region needs.",
    features: [
      "Everything in Growth",
      "SaaS & AI transformation consulting",
      "Staffing & recruitment support",
      "Custom SLA & compliance scope",
      "Priority incident response",
    ],
    featured: false,
  },
];

export default function Pricing() {
  return (
    <section id="pricing" className="mx-auto max-w-7xl px-6 py-28 md:px-10">
      <Reveal className="flex flex-col items-center text-center">
        <Eyebrow index="03" label="Pricing" />
        <h2 className="mt-5 font-display text-5xl leading-[0.95] text-fog md:text-6xl">
          Plans Built to Scale
        </h2>
        <p className="mt-6 max-w-xl text-[14.5px] leading-relaxed text-fog-dim">
          Starting-point plans for common engagement sizes — every scope of work is
          tailored after a discovery call.
        </p>
      </Reveal>

      <div className="mt-16 grid gap-6 md:grid-cols-3">
        {PLANS.map((p, i) => (
          <Reveal
            key={p.name}
            delay={i * 0.1}
            className={`flex flex-col rounded-2xl border p-8 ${
              p.featured
                ? "border-signal bg-panel shadow-[0_8px_30px_rgba(124,58,237,0.12)] md:-translate-y-3"
                : "border-wire bg-panel shadow-[0_2px_12px_rgba(23,21,31,0.04)]"
            }`}
          >
            {p.featured && (
              <span className="mb-4 inline-flex w-fit items-center rounded-full bg-signal px-3 py-1 font-mono text-[10px] uppercase tracking-wide text-white">
                Most Popular
              </span>
            )}
            <h3 className="text-[17px] font-medium text-fog">{p.name}</h3>
            <div className="mt-3 flex items-baseline gap-1">
              <span className="font-display text-4xl text-fog">{p.price}</span>
              <span className="text-[13px] text-fog-dim">{p.period}</span>
            </div>
            <p className="mt-3 text-[13px] leading-relaxed text-fog-dim">{p.desc}</p>

            <ul className="mt-6 flex flex-1 flex-col gap-3">
              {p.features.map((f) => (
                <li key={f} className="flex items-start gap-2.5 text-[13.5px] text-fog">
                  <Check size={15} className="mt-0.5 shrink-0 text-signal" />
                  {f}
                </li>
              ))}
            </ul>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
