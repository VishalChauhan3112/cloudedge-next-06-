"use client";

import { useRouter } from "next/navigation";
import { LogOut } from "lucide-react";

export default function LogoutButton() {
  const router = useRouter();
  return (
    <button
      type="button"
      onClick={async () => {
        await fetch("/api/admin/logout", { method: "POST" });
        router.push("/admin/login");
        router.refresh();
      }}
      className="flex items-center gap-2 rounded-full border border-wire-light px-4 py-2 font-mono text-[12px] text-fog-dim transition-colors hover:border-signal/60 hover:text-signal-soft"
    >
      <LogOut size={13} /> Log Out
    </button>
  );
}
