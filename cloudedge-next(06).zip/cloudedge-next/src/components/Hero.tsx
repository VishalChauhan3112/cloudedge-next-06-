"use client";

import { motion } from "framer-motion";
import { ArrowRight, Calendar } from "lucide-react";

const STATS = [
  { value: "500", suffix: "+", label: "Clients Served", sub: "Across 12 Industries" },
  { value: "3", suffix: "+", label: "Years Experience", sub: "Since 2023" },
];

const TICKER = ["Available 24/7", "SOC 2 Compliant", "HIPAA Ready", "ISO 27001"];

const lineVariants = {
  hidden: { y: "110%" },
  show: (i: number) => ({
    y: "0%",
    transition: { duration: 0.7, delay: 0.15 * i, ease: [0.16, 1, 0.3, 1] as const },
  }),
};

export default function Hero() {
  const words = ["Technology", "Solutions", "That Drive", "Growth"];

  return (
    <section id="home" className="relative overflow-hidden pt-40 pb-24 md:pt-48">
      {/* backdrop grid */}
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.35]"
        style={{
          backgroundImage:
            "linear-gradient(to right, var(--wire) 1px, transparent 1px), linear-gradient(to bottom, var(--wire) 1px, transparent 1px)",
          backgroundSize: "64px 64px",
          maskImage: "radial-gradient(ellipse 80% 60% at 50% 0%, black 40%, transparent 100%)",
        }}
      />
      <div className="pointer-events-none absolute -top-40 left-1/2 h-[560px] w-[560px] -translate-x-1/2 rounded-full bg-signal/[0.07] blur-[140px]" />

      <div className="relative mx-auto grid max-w-7xl gap-16 px-6 md:grid-cols-[1.3fr_1fr] md:px-10">
        <div>
          <motion.div
            initial={{ opacity: 0, x: -12 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            className="mb-6 flex items-center gap-3"
          >
            <span className="h-px w-8 bg-signal" />
            <span className="font-mono text-[12px] uppercase tracking-[0.2em] text-signal-soft">
              Managed Service Provider
            </span>
          </motion.div>

          <h1 className="font-display text-[15vw] leading-[0.88] tracking-tight text-fog md:text-[6.4rem]">
            {words.map((w, i) => (
              <span key={w} className="block overflow-hidden">
                <motion.span
                  className={`inline-block ${i === 2 ? "text-transparent [-webkit-text-stroke:1.5px_var(--fog)]" : ""}`}
                  custom={i}
                  variants={lineVariants}
                  initial="hidden"
                  animate="show"
                >
                  {w}
                </motion.span>
              </span>
            ))}
          </h1>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.7 }}
            className="mt-8 max-w-md text-[15px] leading-relaxed text-fog-dim"
          >
            Transform your business with cutting-edge IT solutions, cybersecurity, and digital
            transformation services. We help modern enterprises scale efficiently and securely.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.85 }}
            className="mt-10 flex flex-wrap items-center gap-4"
          >
            <a
              href="/#contact"
              className="group inline-flex items-center gap-2 rounded-full bg-signal px-7 py-3.5 font-mono text-[13px] font-medium tracking-wide text-void transition-transform hover:scale-[1.03]"
            >
              Apply Now
              <ArrowRight size={15} className="transition-transform group-hover:translate-x-0.5" />
            </a>
            <a
              href="/schedule"
              className="inline-flex items-center gap-2 rounded-full border border-wire-light px-7 py-3.5 font-mono text-[13px] tracking-wide text-fog transition-colors hover:border-signal/60 hover:text-signal-soft"
            >
              Schedule A Call
              <Calendar size={14} />
            </a>
          </motion.div>
        </div>

        <div className="flex flex-col justify-center gap-8 border-t border-wire pt-8 md:border-t-0 md:border-l md:pt-0 md:pl-12">
          {STATS.map((s, i) => (
            <motion.div
              key={s.label}
              initial={{ opacity: 0, x: 12 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.5 + i * 0.12 }}
              className="flex items-baseline gap-4"
            >
              <div className="font-display text-4xl text-fog md:text-5xl">
                {s.value}
                <span className="text-signal">{s.suffix}</span>
              </div>
              <div className="flex flex-col">
                <span className="text-sm text-fog">{s.label}</span>
                <span className="font-mono text-[11px] text-fog-dimmer">{s.sub}</span>
              </div>
            </motion.div>
          ))}

          <div className="mt-4 flex flex-wrap gap-x-6 gap-y-2 border-t border-wire pt-6">
            {TICKER.map((t) => (
              <span
                key={t}
                className="flex items-center gap-2 font-mono text-[11px] uppercase tracking-wide text-fog-dimmer"
              >
                <span className="h-1 w-1 rounded-full bg-circuit" />
                {t}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
