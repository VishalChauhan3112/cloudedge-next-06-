"use client";

import { useState } from "react";
import { MapPin, Phone, Mail, Send, Lock } from "lucide-react";
import Reveal from "./Reveal";
import Eyebrow from "./Eyebrow";

const INFO = [
  {
    icon: MapPin,
    label: "Office",
    value: "123 Business Avenue, Technology Park, TP 12345",
  },
  {
    icon: Phone,
    label: "Phone",
    value: "+1 (430) 837-4007",
    href: "tel:+14308374007",
  },
  {
    icon: Mail,
    label: "Email",
    value: "andrew@cloudedge.com",
    href: "mailto:andrew@cloudedge.com",
  },
];

export default function Contact() {
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  return (
    <section id="contact" className="mx-auto max-w-7xl px-6 py-28 md:px-10">
      <div className="grid gap-16 md:grid-cols-2">
        <div>
          <Reveal>
            <Eyebrow index="07" label="Get In Touch" />
            <h2 className="mt-5 font-display text-5xl leading-[0.95] text-fog md:text-6xl">
              Ready to Transform Your Business?
            </h2>
            <p className="mt-6 max-w-sm text-[14.5px] leading-relaxed text-fog-dim">
              Let&apos;s discuss how our technology solutions can help your business grow, scale,
              and stay secure.
            </p>
          </Reveal>

          <div className="mt-12 flex flex-col gap-6">
            {INFO.map((item, i) => {
              const Icon = item.icon;
              const body = (
                <div className="flex items-start gap-4">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-wire-light text-signal-soft">
                    <Icon size={16} strokeWidth={1.5} />
                  </div>
                  <div>
                    <div className="font-mono text-[11px] uppercase tracking-wide text-fog-dimmer">
                      {item.label}
                    </div>
                    <div className="mt-1 text-[14px] text-fog">{item.value}</div>
                  </div>
                </div>
              );
              return (
                <Reveal key={item.label} delay={i * 0.08}>
                  {item.href ? (
                    <a href={item.href} className="transition-colors hover:text-signal-soft">
                      {body}
                    </a>
                  ) : (
                    body
                  )}
                </Reveal>
              );
            })}
          </div>
        </div>

        <Reveal delay={0.1} className="rounded-2xl border border-wire bg-panel p-8 shadow-[0_2px_16px_rgba(23,21,31,0.05)]">
          <h3 className="text-[17px] font-medium text-fog">Send Us a Message</h3>
          <p className="mt-1 text-[13px] text-fog-dim">
            We&apos;ll get back to you within 1 business day.
          </p>

          {sent ? (
            <div className="mt-8 flex items-center gap-3 rounded-lg border border-signal/30 bg-signal/10 px-4 py-4 text-[13.5px] text-signal-soft">
              Message sent — we&apos;ll be in touch within 1 business day.
            </div>
          ) : (
            <form
              className="mt-8 flex flex-col gap-5"
              onSubmit={async (e) => {
                e.preventDefault();
                setError(null);
                setLoading(true);
                const form = e.currentTarget;
                const data = new FormData(form);
                try {
                  const res = await fetch("/api/contact", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                      name: data.get("name"),
                      email: data.get("email"),
                      company: data.get("company"),
                      phone: data.get("phone"),
                      message: data.get("message"),
                      agree: data.get("agree") === "on",
                    }),
                  });
                  const json = await res.json();
                  if (!res.ok || !json.success) {
                    setError(json.message || "Something went wrong. Please try again.");
                    return;
                  }
                  setSent(true);
                } catch {
                  setError("Network error — please try again.");
                } finally {
                  setLoading(false);
                }
              }}
            >
              {error && (
                <div className="rounded-lg border border-red-400/30 bg-red-400/10 px-4 py-3 text-[13px] text-red-500">
                  {error}
                </div>
              )}
              <div className="grid gap-5 sm:grid-cols-2">
                <Field label="Full Name" required>
                  <input
                    type="text"
                    name="name"
                    required
                    placeholder="John Smith"
                    className="field"
                  />
                </Field>
                <Field label="Email Address" required>
                  <input
                    type="email"
                    name="email"
                    required
                    placeholder="john@company.com"
                    className="field"
                  />
                </Field>
              </div>
              <div className="grid gap-5 sm:grid-cols-2">
                <Field label="Company">
                  <input type="text" name="company" placeholder="Your Company" className="field" />
                </Field>
                <Field label="Phone">
                  <input type="tel" name="phone" placeholder="+1 (555) 000-0000" className="field" />
                </Field>
              </div>
              <Field label="Message" required>
                <textarea
                  name="message"
                  required
                  maxLength={600}
                  rows={4}
                  placeholder="Tell us about your business needs, current challenges, or what you're looking to achieve…"
                  className="field resize-none"
                />
              </Field>

              <label className="flex items-start gap-2.5 text-[12px] leading-relaxed text-fog-dimmer">
                <input type="checkbox" name="agree" required className="mt-1 accent-signal" />
                I agree to CloudEdge&apos;s Privacy Policy and consent to being contacted about
                relevant services.
              </label>

              <div className="mt-1 flex items-center justify-between">
                <button
                  type="submit"
                  disabled={loading}
                  className="inline-flex items-center gap-2 rounded-full bg-signal px-6 py-3 font-mono text-[13px] font-medium text-void transition-transform hover:scale-[1.03] disabled:opacity-60 disabled:hover:scale-100"
                >
                  {loading ? "Sending…" : "Send Message"}
                  <Send size={14} />
                </button>
                <span className="flex items-center gap-1.5 font-mono text-[11px] text-fog-dimmer">
                  <Lock size={11} /> Secured &amp; encrypted
                </span>
              </div>
            </form>
          )}
        </Reveal>
      </div>

      <style jsx global>{`
        .field {
          width: 100%;
          background: var(--void);
          border: 1px solid var(--wire-light);
          border-radius: 8px;
          padding: 10px 14px;
          font-size: 13.5px;
          color: var(--fog);
          font-family: "DM Sans", sans-serif;
        }
        .field::placeholder {
          color: var(--fog-dimmer);
        }
        .field:focus {
          outline: none;
          border-color: var(--signal);
        }
      `}</style>
    </section>
  );
}

function Field({
  label,
  required,
  children,
}: {
  label: string;
  required?: boolean;
  children: React.ReactNode;
}) {
  return (
    <label className="flex flex-col gap-2">
      <span className="font-mono text-[11px] uppercase tracking-wide text-fog-dimmer">
        {label} {required && <span className="text-signal">*</span>}
      </span>
      {children}
    </label>
  );
}
