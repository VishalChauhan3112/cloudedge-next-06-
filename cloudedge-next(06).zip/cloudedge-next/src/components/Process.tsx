import { MessageSquare, ClipboardList, Rocket } from "lucide-react";
import Reveal from "./Reveal";
import Eyebrow from "./Eyebrow";

const STEPS = [
  {
    n: ".01",
    icon: MessageSquare,
    phase: "Discovery",
    title: "Talk Through Your Needs",
    desc: "Send a message or book a call. We discuss your business, current challenges, and what you're looking to achieve.",
  },
  {
    n: ".02",
    icon: ClipboardList,
    phase: "Planning",
    title: "Define Scope & Action Plan",
    desc: "We define scope and share a clear plan with next steps — most engagements start within 3 to 7 business days.",
  },
  {
    n: ".03",
    icon: Rocket,
    phase: "Delivery",
    title: "Deploy & Support",
    desc: "Our team delivers, and stays on for ongoing managed support — urgent issues get same-day triage.",
  },
];

export default function Process() {
  return (
    <section className="border-y border-wire bg-panel/60">
      <div className="mx-auto max-w-7xl px-6 py-28 md:px-10">
        <Reveal className="flex flex-col items-center text-center">
          <Eyebrow index="02" label="Our Process" />
          <h2 className="mt-5 font-display text-5xl leading-[0.95] text-fog md:text-6xl">
            How We Get Started
          </h2>
          <p className="mt-6 max-w-xl text-[14.5px] leading-relaxed text-fog-dim">
            A simple, direct path from first message to a working solution.
          </p>
        </Reveal>

        <div className="mt-16 grid gap-px overflow-hidden rounded-2xl border border-wire bg-wire shadow-[0_1px_2px_rgba(23,21,31,0.04)] md:grid-cols-3">
          {STEPS.map((s, i) => {
            const Icon = s.icon;
            return (
              <Reveal key={s.phase} delay={i * 0.1} className="relative bg-panel p-8">
                <span className="font-display text-5xl text-wire-light">{s.n}</span>
                <div className="mt-6 flex h-11 w-11 items-center justify-center rounded-lg border border-wire-light text-signal-soft">
                  <Icon size={18} strokeWidth={1.5} />
                </div>
                <div className="mt-6 font-mono text-[11px] uppercase tracking-wide text-signal-soft">
                  {s.phase}
                </div>
                <h3 className="mt-2 text-[18px] font-medium text-fog">{s.title}</h3>
                <p className="mt-2 text-[13.5px] leading-relaxed text-fog-dim">{s.desc}</p>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
