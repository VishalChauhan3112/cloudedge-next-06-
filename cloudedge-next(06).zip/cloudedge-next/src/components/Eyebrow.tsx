export default function Eyebrow({
  index,
  label,
}: {
  index: string;
  label: string;
}) {
  return (
    <div className="flex items-center gap-2.5 font-mono text-[11px] tracking-[0.18em] text-signal-soft uppercase">
      <span className="relative flex h-1.5 w-1.5">
        <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-circuit opacity-60" />
        <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-circuit" />
      </span>
      <span className="text-fog-dimmer">{index}</span>
      <span>{label}</span>
    </div>
  );
}
