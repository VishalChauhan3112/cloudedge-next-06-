import { promises as fs } from "fs";
import path from "path";

/**
 * Minimal file-based storage so the contact + schedule forms have a real,
 * working backend out of the box with zero extra dependencies or setup.
 *
 * This mirrors what the original PHP backend did (MySQL INSERT into
 * contact_submissions / call_bookings) but writes to a local JSON file
 * instead, since no database is configured here.
 *
 * ⚠ Before deploying to a serverless platform (Vercel, etc.): the
 * filesystem there is read-only outside /tmp and /tmp is wiped between
 * invocations, so submissions won't persist. Swap `readAll`/`appendOne`
 * below for a real database (Postgres, MySQL, Supabase...) or an email
 * service (Resend, Nodemailer + SMTP) before going live.
 */

const DATA_DIR = path.join(process.cwd(), "data");

async function ensureDataDir() {
  await fs.mkdir(DATA_DIR, { recursive: true });
}

export async function readAll<T>(file: string): Promise<T[]> {
  try {
    const raw = await fs.readFile(path.join(DATA_DIR, file), "utf-8");
    return JSON.parse(raw) as T[];
  } catch {
    return [];
  }
}

export async function appendOne<T extends Record<string, unknown>>(
  file: string,
  record: T
): Promise<void> {
  await ensureDataDir();
  const all = await readAll<T>(file);
  all.push(record);
  await fs.writeFile(path.join(DATA_DIR, file), JSON.stringify(all, null, 2), "utf-8");
}
