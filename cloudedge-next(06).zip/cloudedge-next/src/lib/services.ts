export type ServiceIconName =
  | "brain"
  | "code"
  | "headphones"
  | "users"
  | "megaphone"
  | "graduation-cap"
  | "shield-check";

export interface ServiceData {
  slug: string;
  n: string;
  icon: ServiceIconName;
  title: string;
  /** Short one-liner used in list views (homepage). */
  summary: string;
  /** Full description, from the original index.php service card copy. */
  description: string;
  /** Short phrases pulled directly from the description above — not invented. */
  highlights: string[];
}

export const SERVICES: ServiceData[] = [
  {
    slug: "ai-technology-solutions",
    n: "01",
    icon: "brain",
    title: "AI & Technology Solutions",
    summary:
      "Automation, data insights, and intelligent systems that enhance efficiency, innovation, and competitive advantage.",
    description:
      "Our AI and technology solutions empower organizations with automation, data insights, and intelligent systems that enhance efficiency, innovation, and competitive advantage.",
    highlights: ["Automation", "Data Insights", "Intelligent Systems"],
  },
  {
    slug: "saas-development-consulting",
    n: "02",
    icon: "code",
    title: "SaaS Development & Consulting",
    summary:
      "Scalable cloud platforms that streamline processes, boost productivity, and accelerate business transformation.",
    description:
      "We specialize in SaaS development and consulting, delivering scalable cloud platforms that streamline processes, boost productivity, and accelerate business transformation.",
    highlights: ["Scalable Cloud Platforms", "Streamlined Processes", "Business Transformation"],
  },
  {
    slug: "international-call-centers",
    n: "03",
    icon: "headphones",
    title: "International Call Centers",
    summary:
      "Inbound and outbound support solutions designed to strengthen customer relationships and expand into global markets.",
    description:
      "Delivering customer support that builds trust and drives growth. Our inbound and outbound call center solutions are designed to help businesses strengthen customer relationships, increase sales, and expand into global markets.",
    highlights: ["Inbound & Outbound Support", "Stronger Customer Relationships", "Global Market Expansion"],
  },
  {
    slug: "recruitment-staffing-solutions",
    n: "04",
    icon: "users",
    title: "Recruitment & Staffing Solutions",
    summary:
      "Customized recruitment connecting businesses with skilled professionals who drive performance and culture fit.",
    description:
      "We provide customized recruitment and staffing solutions, connecting businesses with skilled professionals who drive performance, culture fit, and long-term success.",
    highlights: ["Customized Recruitment", "Culture Fit", "Long-Term Success"],
  },
  {
    slug: "digital-marketing-services",
    n: "05",
    icon: "megaphone",
    title: "Digital Marketing Services",
    summary:
      "Impactful strategies across SEO, WordPress, and SMM to strengthen brand presence and engage audiences.",
    description:
      "We design impactful digital marketing strategies with SEO, WordPress solutions, and SMM to strengthen brand presence, engage audiences, and maximize business growth across online platforms.",
    highlights: ["SEO", "WordPress Solutions", "Social Media Marketing"],
  },
  {
    slug: "it-training-mentorship",
    n: "06",
    icon: "graduation-cap",
    title: "IT Training & Mentorship",
    summary:
      "Hands-on training and mentorship that develops practical expertise and career confidence.",
    description:
      "We offer hands-on IT training and mentorship that develops practical expertise, career confidence, and guidance to succeed in today's dynamic technology landscape.",
    highlights: ["Hands-On Training", "Practical Expertise", "Career Mentorship"],
  },
  {
    slug: "managed-it-cybersecurity",
    n: "07",
    icon: "shield-check",
    title: "Managed IT & Cybersecurity",
    summary:
      "Protecting infrastructure, minimizing downtime, and safeguarding sensitive data — always online, always secure.",
    description:
      "Keep your business secure, resilient, and always online. Our IT and cybersecurity services are designed to protect your infrastructure, minimize downtime, and safeguard sensitive data.",
    highlights: ["Infrastructure Protection", "Minimized Downtime", "Data Safeguarding"],
  },
];

export function getService(slug: string): ServiceData | undefined {
  return SERVICES.find((s) => s.slug === slug);
}
