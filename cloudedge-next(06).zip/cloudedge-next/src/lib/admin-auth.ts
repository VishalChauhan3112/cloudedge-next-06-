export const ADMIN_COOKIE = "cloudedge_admin_session";

function getSecret() {
  // Falls back to the password itself if no separate secret is set — still
  // fine for a single-admin internal tool, but set ADMIN_SESSION_SECRET in
  // production for a cleaner separation between "password" and "signing key".
  return process.env.ADMIN_SESSION_SECRET || process.env.ADMIN_PASSWORD || "cloudedge-dev-secret";
}

// Uses Web Crypto (globalThis.crypto.subtle) instead of Node's `crypto`
// module so this works in both the Edge middleware runtime and normal
// server routes without any extra config.
async function hmacHex(message: string, secret: string): Promise<string> {
  const enc = new TextEncoder();
  const key = await crypto.subtle.importKey(
    "raw",
    enc.encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const sig = await crypto.subtle.sign("HMAC", key, enc.encode(message));
  return Array.from(new Uint8Array(sig))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

/** Deterministic signed token — no server-side session store needed. */
export async function makeSessionToken(): Promise<string> {
  return hmacHex("cloudedge-admin-session", getSecret());
}

export async function isValidSessionToken(token: string | undefined): Promise<boolean> {
  if (!token) return false;
  const expected = await makeSessionToken();
  if (token.length !== expected.length) return false;
  // Constant-time-ish comparison (fine at this string length for this use case).
  let diff = 0;
  for (let i = 0; i < token.length; i++) {
    diff |= token.charCodeAt(i) ^ expected.charCodeAt(i);
  }
  return diff === 0;
}
