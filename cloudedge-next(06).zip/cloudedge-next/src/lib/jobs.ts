/**
 * PLACEHOLDER CONTENT — these are illustrative example listings so the
 * careers page has real structure and content to show. Replace with your
 * actual open roles before publishing (or empty the array to show
 * "No open positions right now").
 */

export interface JobData {
  slug: string;
  title: string;
  department: string;
  location: string;
  type: string;
  summary: string;
  responsibilities: string[];
  requirements: string[];
}

export const JOBS: JobData[] = [
  {
    slug: "managed-it-support-engineer",
    title: "Managed IT Support Engineer",
    department: "Managed IT & Cybersecurity",
    location: "India (Remote)",
    type: "Full-time",
    summary:
      "Own day-to-day IT support and monitoring for our managed services clients — the first line of defense keeping their infrastructure online.",
    responsibilities: [
      "Monitor client infrastructure and respond to incidents within SLA",
      "Triage and resolve helpdesk tickets across a range of environments",
      "Maintain backup, patching, and security review schedules",
      "Escalate complex issues with clear documentation",
    ],
    requirements: [
      "2+ years in IT support or a managed services environment",
      "Comfortable across Windows/Linux server administration",
      "Strong written communication for client-facing tickets",
    ],
  },
  {
    slug: "saas-implementation-consultant",
    title: "SaaS Implementation Consultant",
    department: "SaaS Development & Consulting",
    location: "India / US (Remote)",
    type: "Full-time",
    summary:
      "Guide clients through scoping, configuring, and rolling out SaaS platforms that streamline their operations.",
    responsibilities: [
      "Run discovery calls to scope client requirements",
      "Configure and customize SaaS platforms for client workflows",
      "Train client teams during rollout",
      "Partner with engineering on custom integration needs",
    ],
    requirements: [
      "Experience implementing or consulting on SaaS platforms",
      "Comfortable leading client-facing calls independently",
      "Basic scripting/API familiarity a plus",
    ],
  },
  {
    slug: "technical-recruiter",
    title: "Technical Recruiter",
    department: "Recruitment & Staffing",
    location: "India (Hybrid)",
    type: "Full-time",
    summary:
      "Source and place skilled technical talent for our staffing clients, from first screen through offer.",
    responsibilities: [
      "Source candidates for technical and IT roles",
      "Screen for both skill fit and culture fit",
      "Manage the interview pipeline end-to-end",
      "Build relationships with a growing candidate network",
    ],
    requirements: [
      "1+ years technical recruiting experience",
      "Strong sense for matching skills to client needs",
      "Organized, high-communication working style",
    ],
  },
];

export function getJob(slug: string): JobData | undefined {
  return JOBS.find((j) => j.slug === slug);
}
