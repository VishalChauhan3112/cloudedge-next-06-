/**
 * PLACEHOLDER CONTENT — illustrative example case studies so the page has
 * real structure. Replace with real client projects (with permission)
 * before publishing.
 */

export interface CaseStudyData {
  slug: string;
  client: string;
  industry: string;
  service: string;
  title: string;
  summary: string;
  challenge: string;
  solution: string;
  results: { metric: string; label: string }[];
}

export const CASE_STUDIES: CaseStudyData[] = [
  {
    slug: "fintech-cloud-migration",
    client: "Example Fintech Co.",
    industry: "Financial Services",
    service: "SaaS Development & Consulting",
    title: "Migrating a Legacy Platform to a Scalable Cloud Architecture",
    summary:
      "A mid-size fintech startup needed to move off an aging on-premise system without disrupting daily operations.",
    challenge:
      "The client's core platform ran on infrastructure that couldn't scale with their growing transaction volume, and downtime during business hours wasn't an option.",
    solution:
      "We planned a phased migration to a cloud-native architecture, running the new and old systems in parallel until every workflow was validated, then cut over during a scheduled low-traffic window.",
    results: [
      { metric: "0", label: "Minutes of unplanned downtime" },
      { metric: "3x", label: "Transaction throughput capacity" },
      { metric: "6 wks", label: "From kickoff to full cutover" },
    ],
  },
  {
    slug: "healthcare-msp-transition",
    client: "Example Healthcare Group",
    industry: "Healthcare",
    service: "Managed IT & Cybersecurity",
    title: "Transitioning to Managed IT Without Missing a Beat",
    summary:
      "A multi-location healthcare provider needed a new managed IT partner after outgrowing their previous vendor.",
    challenge:
      "Sensitive patient data and multiple clinic locations meant the transition had to be secure, compliant, and effectively invisible to clinical staff.",
    solution:
      "We ran infrastructure discovery across every location, built a compliant monitoring and backup baseline, and staged the vendor handoff so clinics never lost support coverage.",
    results: [
      { metric: "12", label: "Locations onboarded" },
      { metric: "99.9%", label: "Helpdesk response within SLA" },
      { metric: "0", label: "Compliance gaps found post-audit" },
    ],
  },
];

export function getCaseStudy(slug: string): CaseStudyData | undefined {
  return CASE_STUDIES.find((c) => c.slug === slug);
}
