import { SERVICES } from "./services";
import { BLOG_POSTS } from "./blog";
import { CASE_STUDIES } from "./case-studies";
import { JOBS } from "./jobs";
import { RESOURCES } from "./resources";

export interface SearchItem {
  title: string;
  description: string;
  url: string;
  category: string;
}

export function buildSearchIndex(): SearchItem[] {
  return [
    ...SERVICES.map((s) => ({
      title: s.title,
      description: s.summary,
      url: `/services/${s.slug}`,
      category: "Service",
    })),
    ...BLOG_POSTS.map((p) => ({
      title: p.title,
      description: p.excerpt,
      url: `/blog/${p.slug}`,
      category: "Blog",
    })),
    ...CASE_STUDIES.map((c) => ({
      title: c.title,
      description: c.summary,
      url: `/case-studies/${c.slug}`,
      category: "Case Study",
    })),
    ...JOBS.map((j) => ({
      title: j.title,
      description: j.summary,
      url: `/careers/${j.slug}`,
      category: "Careers",
    })),
    ...RESOURCES.map((r) => ({
      title: r.title,
      description: r.description,
      url: r.href,
      category: "Resource",
    })),
    {
      title: "About CloudEdge",
      description: "Our mission, global footprint, and operating values.",
      url: "/about",
      category: "Page",
    },
    {
      title: "Schedule A Call",
      description: "Book a 30-minute call with our team.",
      url: "/schedule",
      category: "Page",
    },
    {
      title: "Downtime Cost Calculator",
      description: "Estimate what IT downtime is costing your business.",
      url: "/roi-calculator",
      category: "Page",
    },
    {
      title: "System Status",
      description: "Current status of CloudEdge-managed systems.",
      url: "/status",
      category: "Page",
    },
    {
      title: "Pricing",
      description: "Starting-point plans for common engagement sizes.",
      url: "/#pricing",
      category: "Page",
    },
  ];
}
