export interface ResourceData {
  slug: string;
  title: string;
  description: string;
  category: string;
  fileSize: string;
  href: string;
}

export const RESOURCES: ResourceData[] = [
  {
    slug: "it-security-checklist",
    title: "IT Security Checklist for Small Businesses",
    description:
      "A practical, no-budget-required starting point for reducing your business's exposure to common security risks.",
    category: "Cybersecurity",
    fileSize: "1 page · PDF",
    href: "/resources/it-security-checklist.pdf",
  },
  {
    slug: "cloud-migration-checklist",
    title: "Cloud Migration Readiness Checklist",
    description:
      "Questions worth answering before you move a system to the cloud — most migration problems trace back to one of these being skipped.",
    category: "Cloud & SaaS",
    fileSize: "1 page · PDF",
    href: "/resources/cloud-migration-checklist.pdf",
  },
];
