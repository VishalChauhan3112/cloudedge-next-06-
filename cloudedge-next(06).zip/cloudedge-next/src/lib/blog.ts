/**
 * DRAFT CONTENT — these posts are genuinely-written starter content (general
 * IT/security best practices, not company-specific claims), so the blog has
 * real substance on day one. Review, add a byline, and edit to taste before
 * publishing — none of this claims to be CloudEdge-specific case history.
 */

export interface BlogPostData {
  slug: string;
  title: string;
  excerpt: string;
  category: string;
  readTime: string;
  date: string; // ISO
  body: string[]; // paragraphs
}

export const BLOG_POSTS: BlogPostData[] = [
  {
    slug: "signs-your-business-has-outgrown-its-it-support",
    title: "5 Signs Your Business Has Outgrown Its Current IT Support",
    excerpt:
      "Recurring downtime, slow ticket response, and a growing list of workarounds are common signs it's time to reassess your IT support model.",
    category: "Managed IT",
    readTime: "4 min read",
    date: "2026-06-02",
    body: [
      "Most businesses don't plan to outgrow their IT support — it happens gradually, as headcount, systems, and data grow faster than the support model keeping up with them.",
      "A few patterns tend to show up first: tickets that used to close in hours start taking days, the same issues keep recurring without a permanent fix, and your team starts building informal workarounds just to keep working.",
      "Security review is often the first thing to slip. When support is reactive rather than proactive, patching and monitoring get deprioritized in favor of firefighting — which quietly increases risk over time.",
      "Scaling pains show up next: onboarding new hires takes longer, new locations or remote staff strain a support model built for a smaller footprint, and IT spend becomes unpredictable because everything is handled ad hoc.",
      "None of these signs mean something is broken — they usually just mean the support model that worked at an earlier stage needs to evolve alongside the business. A structured review of current tooling, response times, and security posture is usually the right first step.",
    ],
  },
  {
    slug: "cloud-migration-common-pitfalls",
    title: "Cloud Migration: Common Pitfalls and How to Avoid Them",
    excerpt:
      "Most failed cloud migrations don't fail on the technology — they fail on planning. Here's what tends to go wrong, and how to avoid it.",
    category: "Cloud & SaaS",
    readTime: "5 min read",
    date: "2026-05-14",
    body: [
      "Cloud migration projects rarely fail because the cloud platform can't handle the workload. They fail because of planning gaps that only surface once the migration is underway.",
      "The most common pitfall is underestimating dependencies — a system rarely stands alone, and migrating it without mapping what talks to it first tends to surface surprise breakages mid-project.",
      "A close second is skipping a parallel-run period. Cutting over all at once, with no fallback window, turns any unexpected issue into a full outage instead of a manageable one.",
      "Cost is another common surprise: cloud infrastructure is usage-based, and workloads that weren't sized correctly before migrating often come in well over budget in the first few months.",
      "The migrations that go smoothly share a pattern: a full dependency map before anything moves, a staged rollout with a real rollback plan, and cost modeling based on actual usage patterns — not just a lift-and-shift estimate.",
    ],
  },
  {
    slug: "cybersecurity-basics-every-smb-needs",
    title: "Cybersecurity Basics Every Small Business Needs (Even Without a Security Team)",
    excerpt:
      "You don't need an in-house security team to meaningfully reduce your risk. A handful of fundamentals cover most of the exposure.",
    category: "Cybersecurity",
    readTime: "4 min read",
    date: "2026-04-22",
    body: [
      "Most successful attacks on small businesses don't involve sophisticated exploits — they involve basic gaps that a handful of fundamentals would have closed.",
      "Multi-factor authentication on every account that supports it is the single highest-leverage change most businesses can make, and it's usually a same-day rollout.",
      "Regular, tested backups matter more than any other single control when it comes to ransomware — an attack that would otherwise be catastrophic becomes a recovery exercise if backups are current and actually restorable.",
      "Patching on a schedule, rather than reactively, closes the window attackers rely on. Most breaches exploit vulnerabilities that already had a patch available.",
      "Finally, basic staff awareness — recognizing phishing attempts, verifying unusual payment requests — closes the human gap that technical controls alone can't cover. None of this requires an in-house security team; it requires a consistent process.",
    ],
  },
];

export function getBlogPost(slug: string): BlogPostData | undefined {
  return BLOG_POSTS.find((p) => p.slug === slug);
}
