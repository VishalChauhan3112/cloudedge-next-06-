import type { Metadata } from "next";
import Reveal from "@/components/Reveal";
import Eyebrow from "@/components/Eyebrow";
import ScheduleForm from "@/components/ScheduleForm";

export const metadata: Metadata = {
  title: "Schedule A Call — CloudEdge Tech Services",
  description:
    "Book a 30-minute call with CloudEdge to talk through your project and explore how we can help your business grow.",
};

export default function SchedulePage() {
  return (
    <section className="mx-auto max-w-5xl px-6 pb-28 pt-40 md:px-10 md:pt-48">
      <Reveal className="text-center">
        <Eyebrow index="—" label="CloudEdge Tech Services" />
        <h1 className="mt-5 font-display text-5xl leading-[0.95] text-fog md:text-6xl">
          Schedule A Call
        </h1>
        <p className="mx-auto mt-6 max-w-xl text-[14.5px] leading-relaxed text-fog-dim">
          Let&apos;s talk about your project. We&apos;ll walk you through our solutions and
          explore how CloudEdge can help your business grow.
        </p>
      </Reveal>

      <Reveal delay={0.1} className="mt-14">
        <ScheduleForm />
      </Reveal>
    </section>
  );
}
