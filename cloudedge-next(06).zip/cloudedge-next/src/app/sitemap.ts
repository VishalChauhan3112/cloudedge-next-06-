import type { MetadataRoute } from "next";
import { SERVICES } from "@/lib/services";
import { JOBS } from "@/lib/jobs";
import { CASE_STUDIES } from "@/lib/case-studies";
import { BLOG_POSTS } from "@/lib/blog";

export default function sitemap(): MetadataRoute.Sitemap {
  const base = process.env.SITE_URL || "http://localhost:3000";

  const staticPages = [
    "",
    "/about",
    "/schedule",
    "/careers",
    "/case-studies",
    "/blog",
    "/resources",
    "/roi-calculator",
    "/status",
    "/search",
  ].map((path) => ({
    url: `${base}${path}`,
    lastModified: new Date(),
  }));

  const servicePages = SERVICES.map((s) => ({
    url: `${base}/services/${s.slug}`,
    lastModified: new Date(),
  }));

  const jobPages = JOBS.map((j) => ({
    url: `${base}/careers/${j.slug}`,
    lastModified: new Date(),
  }));

  const caseStudyPages = CASE_STUDIES.map((c) => ({
    url: `${base}/case-studies/${c.slug}`,
    lastModified: new Date(),
  }));

  const blogPages = BLOG_POSTS.map((p) => ({
    url: `${base}/blog/${p.slug}`,
    lastModified: new Date(p.date),
  }));

  return [...staticPages, ...servicePages, ...jobPages, ...caseStudyPages, ...blogPages];
}
