import type { Metadata } from "next";
import { Download, FileText } from "lucide-react";
import Reveal from "@/components/Reveal";
import Eyebrow from "@/components/Eyebrow";
import { RESOURCES } from "@/lib/resources";

export const metadata: Metadata = {
  title: "Resources — CloudEdge Tech Services",
  description: "Free guides and checklists on IT security, cloud migration, and more.",
};

export default function ResourcesPage() {
  return (
    <section className="mx-auto max-w-5xl px-6 pb-28 pt-40 md:px-10 md:pt-48">
      <Reveal className="text-center">
        <Eyebrow index="—" label="Resources" />
        <h1 className="mt-5 font-display text-6xl leading-[0.95] text-fog md:text-7xl">
          Free Guides &amp; Checklists
        </h1>
        <p className="mx-auto mt-6 max-w-xl text-[14.5px] leading-relaxed text-fog-dim">
          Practical, no-strings-attached resources you can use whether or not you ever
          work with us.
        </p>
      </Reveal>

      <div className="mt-16 grid gap-6 md:grid-cols-2">
        {RESOURCES.map((r, i) => (
          <Reveal key={r.slug} delay={i * 0.08}>
            <a
              href={r.href}
              download
              className="group flex h-full flex-col rounded-2xl border border-wire bg-panel p-8 shadow-[0_2px_12px_rgba(23,21,31,0.04)] transition-colors hover:border-signal/50"
            >
              <div className="flex h-11 w-11 items-center justify-center rounded-lg border border-wire-light text-signal-soft transition-colors group-hover:border-signal group-hover:text-signal">
                <FileText size={20} strokeWidth={1.5} />
              </div>
              <span className="mt-5 font-mono text-[11px] uppercase tracking-wide text-signal-soft">
                {r.category}
              </span>
              <h2 className="mt-2 text-[18px] font-medium leading-snug text-fog">{r.title}</h2>
              <p className="mt-2 flex-1 text-[13.5px] leading-relaxed text-fog-dim">
                {r.description}
              </p>
              <div className="mt-6 flex items-center justify-between font-mono text-[11px] text-fog-dimmer">
                <span>{r.fileSize}</span>
                <span className="flex items-center gap-1.5 text-signal-soft">
                  Download <Download size={13} />
                </span>
              </div>
            </a>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
