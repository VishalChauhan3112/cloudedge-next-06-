import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { BLOG_POSTS, getBlogPost } from "@/lib/blog";
import Reveal from "@/components/Reveal";
import Eyebrow from "@/components/Eyebrow";
import CTA from "@/components/CTA";

export function generateStaticParams() {
  return BLOG_POSTS.map((p) => ({ slug: p.slug }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const post = getBlogPost(slug);
  if (!post) return {};
  return { title: `${post.title} — CloudEdge Blog`, description: post.excerpt };
}

export default async function BlogPostPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const post = getBlogPost(slug);
  if (!post) notFound();

  return (
    <>
      <script
        type="application/ld+json"
        // eslint-disable-next-line react/no-danger
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "Article",
            headline: post.title,
            description: post.excerpt,
            datePublished: post.date,
            author: { "@type": "Organization", name: "CloudEdge Tech Services" },
          }),
        }}
      />
      <article className="mx-auto max-w-2xl px-6 pb-20 pt-40 md:px-10 md:pt-48">
        <Reveal>
          <Link
            href="/blog"
            className="inline-flex items-center gap-2 font-mono text-[12px] text-fog-dim transition-colors hover:text-signal-soft"
          >
            <ArrowLeft size={14} /> All Posts
          </Link>
        </Reveal>

        <Reveal delay={0.05}>
          <Eyebrow index="—" label={post.category} />
        </Reveal>

        <Reveal delay={0.1}>
          <h1 className="mt-5 font-display text-4xl leading-[1.05] text-fog md:text-5xl">
            {post.title}
          </h1>
        </Reveal>

        <Reveal
          delay={0.15}
          className="mt-4 flex items-center gap-3 font-mono text-[11px] uppercase tracking-wide text-fog-dimmer"
        >
          <time dateTime={post.date}>
            {new Date(post.date).toLocaleDateString("en-US", {
              month: "long",
              day: "numeric",
              year: "numeric",
            })}
          </time>
          <span>·</span>
          <span>{post.readTime}</span>
        </Reveal>

        <Reveal delay={0.2} className="mt-10 flex flex-col gap-5">
          {post.body.map((para, i) => (
            <p key={i} className="text-[15px] leading-relaxed text-fog-dim">
              {para}
            </p>
          ))}
        </Reveal>
      </article>

      <CTA
        title="Have Questions About This?"
        subtitle="We're happy to walk through how this applies to your specific setup."
      />
    </>
  );
}
