import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight } from "lucide-react";
import Reveal from "@/components/Reveal";
import Eyebrow from "@/components/Eyebrow";
import { BLOG_POSTS } from "@/lib/blog";

export const metadata: Metadata = {
  title: "Blog — CloudEdge Tech Services",
  description: "IT, cloud, and cybersecurity insights from CloudEdge Tech Services.",
};

export default function BlogPage() {
  return (
    <section className="mx-auto max-w-5xl px-6 pb-28 pt-40 md:px-10 md:pt-48">
      <Reveal className="text-center">
        <Eyebrow index="—" label="Blog" />
        <h1 className="mt-5 font-display text-6xl leading-[0.95] text-fog md:text-7xl">
          Insights &amp; Updates
        </h1>
        <p className="mx-auto mt-6 max-w-xl text-[14.5px] leading-relaxed text-fog-dim">
          Practical thinking on managed IT, cloud, and cybersecurity.
        </p>
      </Reveal>

      <div className="mt-16 border-t border-wire">
        {BLOG_POSTS.map((post, i) => (
          <Reveal key={post.slug} delay={Math.min(i * 0.06, 0.24)}>
            <Link
              href={`/blog/${post.slug}`}
              className="group flex flex-col gap-3 border-b border-wire py-8 transition-colors hover:bg-panel-hover md:px-4"
            >
              <div className="flex items-center gap-3 font-mono text-[11px] uppercase tracking-wide text-fog-dimmer">
                <span className="text-signal-soft">{post.category}</span>
                <span>·</span>
                <span>{post.readTime}</span>
                <span>·</span>
                <time dateTime={post.date}>
                  {new Date(post.date).toLocaleDateString("en-US", {
                    month: "long",
                    day: "numeric",
                    year: "numeric",
                  })}
                </time>
              </div>
              <h2 className="text-[20px] font-medium leading-snug text-fog md:text-[22px]">
                {post.title}
              </h2>
              <p className="max-w-2xl text-[13.5px] leading-relaxed text-fog-dim">
                {post.excerpt}
              </p>
              <span className="mt-1 flex items-center gap-2 font-mono text-[12px] text-signal-soft opacity-0 transition-opacity group-hover:opacity-100">
                Read more <ArrowRight size={13} />
              </span>
            </Link>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
