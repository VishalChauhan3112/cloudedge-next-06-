import type { Metadata } from "next";
import { CheckCircle2 } from "lucide-react";
import Reveal from "@/components/Reveal";
import Eyebrow from "@/components/Eyebrow";

export const metadata: Metadata = {
  title: "System Status — CloudEdge Tech Services",
  description: "Current status of CloudEdge-managed systems and services.",
};

/**
 * PLACEHOLDER DATA — this list and every status below are illustrative.
 * Before publishing, wire this up to a real monitoring source: either
 * a hosted status-page provider (Better Stack, Statuspage, UptimeRobot's
 * public status pages all offer embeddable/API options), or your own
 * uptime checks written to a small database and read here.
 */
const SYSTEMS = [
  { name: "Managed IT Helpdesk", status: "operational" as const },
  { name: "Client Cloud Infrastructure", status: "operational" as const },
  { name: "Backup & Recovery Services", status: "operational" as const },
  { name: "Cybersecurity Monitoring", status: "operational" as const },
  { name: "Client Portal", status: "operational" as const },
];

const STATUS_STYLES = {
  operational: { label: "Operational", color: "text-emerald-600", dot: "bg-emerald-500" },
  degraded: { label: "Degraded Performance", color: "text-amber-600", dot: "bg-amber-500" },
  outage: { label: "Outage", color: "text-red-600", dot: "bg-red-500" },
};

export default function StatusPage() {
  const allOperational = SYSTEMS.every((s) => s.status === "operational");

  return (
    <section className="mx-auto max-w-3xl px-6 pb-28 pt-40 md:px-10 md:pt-48">
      <Reveal className="text-center">
        <Eyebrow index="—" label="System Status" />
        <h1 className="mt-5 font-display text-5xl leading-[0.95] text-fog md:text-6xl">
          System Status
        </h1>
      </Reveal>

      <Reveal
        delay={0.1}
        className={`mt-10 flex items-center justify-center gap-3 rounded-2xl border p-6 ${
          allOperational
            ? "border-emerald-500/30 bg-emerald-500/5"
            : "border-amber-500/30 bg-amber-500/5"
        }`}
      >
        <CheckCircle2 size={22} className={allOperational ? "text-emerald-600" : "text-amber-600"} />
        <span className="text-[16px] font-medium text-fog">
          {allOperational ? "All Systems Operational" : "Some Systems Experiencing Issues"}
        </span>
      </Reveal>

      <Reveal delay={0.15} className="mt-10 divide-y divide-wire border-y border-wire">
        {SYSTEMS.map((s) => {
          const style = STATUS_STYLES[s.status];
          return (
            <div key={s.name} className="flex items-center justify-between py-5">
              <span className="text-[14px] text-fog">{s.name}</span>
              <span className={`flex items-center gap-2 font-mono text-[12px] ${style.color}`}>
                <span className={`h-2 w-2 rounded-full ${style.dot}`} />
                {style.label}
              </span>
            </div>
          );
        })}
      </Reveal>

      <Reveal delay={0.2} className="mt-10">
        <h2 className="text-[14px] font-medium text-fog">Past Incidents</h2>
        <p className="mt-3 text-[13.5px] leading-relaxed text-fog-dim">
          No incidents reported in the last 90 days.
        </p>
      </Reveal>
    </section>
  );
}
