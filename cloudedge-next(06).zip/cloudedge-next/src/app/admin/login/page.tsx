"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Lock } from "lucide-react";

export default function AdminLoginPage() {
  const router = useRouter();
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  return (
    <section className="mx-auto flex min-h-[80vh] max-w-sm flex-col justify-center px-6">
      <div className="rounded-2xl border border-wire bg-panel p-8 shadow-[0_2px_16px_rgba(23,21,31,0.05)]">
        <div className="flex h-11 w-11 items-center justify-center rounded-lg border border-wire-light text-signal-soft">
          <Lock size={18} />
        </div>
        <h1 className="mt-5 font-display text-3xl text-fog">Admin Login</h1>
        <p className="mt-1 text-[13px] text-fog-dim">View site submissions and bookings.</p>

        <form
          className="mt-7 flex flex-col gap-4"
          onSubmit={async (e) => {
            e.preventDefault();
            setError(null);
            setLoading(true);
            try {
              const res = await fetch("/api/admin/login", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ password }),
              });
              const json = await res.json();
              if (!res.ok || !json.success) {
                setError(json.message || "Incorrect password.");
                return;
              }
              router.push("/admin");
              router.refresh();
            } catch {
              setError("Network error — please try again.");
            } finally {
              setLoading(false);
            }
          }}
        >
          {error && (
            <div className="rounded-lg border border-red-400/30 bg-red-400/10 px-4 py-3 text-[13px] text-red-500">
              {error}
            </div>
          )}
          <input
            type="password"
            required
            autoFocus
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Password"
            className="w-full rounded-lg border border-wire-light bg-void px-4 py-3 text-[14px] text-fog placeholder:text-fog-dimmer focus:border-signal focus:outline-none"
          />
          <button
            type="submit"
            disabled={loading}
            className="rounded-full bg-signal px-6 py-3 font-mono text-[13px] font-medium text-white transition-transform hover:scale-[1.02] disabled:opacity-60"
          >
            {loading ? "Checking…" : "Log In"}
          </button>
        </form>
      </div>
    </section>
  );
}
