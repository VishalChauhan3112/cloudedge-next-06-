import { readAll } from "@/lib/submissions";
import LogoutButton from "@/components/LogoutButton";

export const dynamic = "force-dynamic";

interface ContactSubmission {
  name: string;
  email: string;
  company: string | null;
  phone: string | null;
  message: string;
  submitted_at: string;
}
interface CallBooking {
  full_name: string;
  mobile: string;
  call_date: string;
  call_time: string;
  booked_at: string;
}
interface NewsletterSubscriber {
  email: string;
  subscribed_at: string;
}
interface JobApplication {
  job_title: string;
  name: string;
  email: string;
  phone: string | null;
  message: string;
  applied_at: string;
}

function fmt(iso: string) {
  try {
    return new Date(iso).toLocaleString("en-US", {
      dateStyle: "medium",
      timeStyle: "short",
    });
  } catch {
    return iso;
  }
}

function Section({
  title,
  count,
  children,
}: {
  title: string;
  count: number;
  children: React.ReactNode;
}) {
  return (
    <div className="rounded-2xl border border-wire bg-panel shadow-[0_2px_12px_rgba(23,21,31,0.04)]">
      <div className="flex items-center justify-between border-b border-wire px-6 py-4">
        <h2 className="text-[15px] font-medium text-fog">{title}</h2>
        <span className="font-mono text-[11px] text-fog-dimmer">{count}</span>
      </div>
      <div className="max-h-[420px] overflow-y-auto">{children}</div>
    </div>
  );
}

function Empty() {
  return <p className="px-6 py-8 text-center text-[13px] text-fog-dim">Nothing here yet.</p>;
}

export default async function AdminDashboard() {
  const [contacts, bookings, subscribers, applications] = await Promise.all([
    readAll<ContactSubmission>("contact-submissions.json"),
    readAll<CallBooking>("call-bookings.json"),
    readAll<NewsletterSubscriber>("newsletter-subscribers.json"),
    readAll<JobApplication>("job-applications.json"),
  ]);

  return (
    <section className="mx-auto max-w-6xl px-6 py-12 md:px-10">
      <div className="flex items-center justify-between">
        <h1 className="font-display text-4xl text-fog">Admin Dashboard</h1>
        <LogoutButton />
      </div>
      <p className="mt-2 text-[13px] text-fog-dim">
        Everything submitted through the site&apos;s forms. Stored locally under{" "}
        <code className="rounded bg-void px-1.5 py-0.5 font-mono text-[12px]">/data</code> — see
        the README for swapping this to a real database before production.
      </p>

      <div className="mt-10 grid gap-6 md:grid-cols-2">
        <Section title="Contact Submissions" count={contacts.length}>
          {contacts.length === 0 ? (
            <Empty />
          ) : (
            <ul className="divide-y divide-wire">
              {[...contacts].reverse().map((c, i) => (
                <li key={i} className="px-6 py-4">
                  <div className="flex items-center justify-between">
                    <span className="text-[13.5px] font-medium text-fog">{c.name}</span>
                    <span className="font-mono text-[10px] text-fog-dimmer">
                      {fmt(c.submitted_at)}
                    </span>
                  </div>
                  <div className="mt-1 text-[12px] text-fog-dim">
                    {c.email} {c.company ? `· ${c.company}` : ""} {c.phone ? `· ${c.phone}` : ""}
                  </div>
                  <p className="mt-2 text-[13px] leading-relaxed text-fog">{c.message}</p>
                </li>
              ))}
            </ul>
          )}
        </Section>

        <Section title="Call Bookings" count={bookings.length}>
          {bookings.length === 0 ? (
            <Empty />
          ) : (
            <ul className="divide-y divide-wire">
              {[...bookings].reverse().map((b, i) => (
                <li key={i} className="flex items-center justify-between px-6 py-4">
                  <div>
                    <span className="text-[13.5px] font-medium text-fog">{b.full_name}</span>
                    <div className="mt-1 text-[12px] text-fog-dim">{b.mobile}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-[13px] text-fog">
                      {b.call_date} · {b.call_time}
                    </div>
                    <div className="font-mono text-[10px] text-fog-dimmer">
                      booked {fmt(b.booked_at)}
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </Section>

        <Section title="Newsletter Subscribers" count={subscribers.length}>
          {subscribers.length === 0 ? (
            <Empty />
          ) : (
            <ul className="divide-y divide-wire">
              {[...subscribers].reverse().map((s, i) => (
                <li key={i} className="flex items-center justify-between px-6 py-4">
                  <span className="text-[13.5px] text-fog">{s.email}</span>
                  <span className="font-mono text-[10px] text-fog-dimmer">
                    {fmt(s.subscribed_at)}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </Section>

        <Section title="Job Applications" count={applications.length}>
          {applications.length === 0 ? (
            <Empty />
          ) : (
            <ul className="divide-y divide-wire">
              {[...applications].reverse().map((a, i) => (
                <li key={i} className="px-6 py-4">
                  <div className="flex items-center justify-between">
                    <span className="text-[13.5px] font-medium text-fog">{a.name}</span>
                    <span className="font-mono text-[10px] text-fog-dimmer">
                      {fmt(a.applied_at)}
                    </span>
                  </div>
                  <div className="mt-1 text-[12px] text-fog-dim">
                    {a.job_title} · {a.email}
                  </div>
                  <p className="mt-2 text-[13px] leading-relaxed text-fog">{a.message}</p>
                </li>
              ))}
            </ul>
          )}
        </Section>
      </div>
    </section>
  );
}
