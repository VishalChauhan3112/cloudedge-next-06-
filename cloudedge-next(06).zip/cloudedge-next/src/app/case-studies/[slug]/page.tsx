import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { CASE_STUDIES, getCaseStudy } from "@/lib/case-studies";
import Reveal from "@/components/Reveal";
import Eyebrow from "@/components/Eyebrow";
import CTA from "@/components/CTA";

export function generateStaticParams() {
  return CASE_STUDIES.map((c) => ({ slug: c.slug }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const cs = getCaseStudy(slug);
  if (!cs) return {};
  return { title: `${cs.title} — CloudEdge Case Studies`, description: cs.summary };
}

export default async function CaseStudyDetailPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const cs = getCaseStudy(slug);
  if (!cs) notFound();

  return (
    <>
      <section className="mx-auto max-w-3xl px-6 pb-20 pt-40 md:px-10 md:pt-48">
        <Reveal>
          <Link
            href="/case-studies"
            className="inline-flex items-center gap-2 font-mono text-[12px] text-fog-dim transition-colors hover:text-signal-soft"
          >
            <ArrowLeft size={14} /> All Case Studies
          </Link>
        </Reveal>

        <Reveal delay={0.05}>
          <Eyebrow index="—" label={`${cs.industry} · ${cs.service}`} />
        </Reveal>

        <Reveal delay={0.1}>
          <h1 className="mt-5 font-display text-4xl leading-[1] text-fog md:text-5xl">
            {cs.title}
          </h1>
        </Reveal>

        <Reveal delay={0.15}>
          <p className="mt-3 font-mono text-[12px] text-fog-dimmer">{cs.client}</p>
        </Reveal>

        <Reveal delay={0.2} className="mt-10 grid grid-cols-3 gap-6 border-y border-wire py-8">
          {cs.results.map((r) => (
            <div key={r.label}>
              <div className="font-display text-3xl text-fog md:text-4xl">{r.metric}</div>
              <div className="mt-1 text-[12px] leading-snug text-fog-dim">{r.label}</div>
            </div>
          ))}
        </Reveal>

        <Reveal delay={0.25} className="mt-10">
          <h2 className="text-[15px] font-medium text-fog">The Challenge</h2>
          <p className="mt-3 text-[14px] leading-relaxed text-fog-dim">{cs.challenge}</p>
        </Reveal>

        <Reveal delay={0.3} className="mt-8">
          <h2 className="text-[15px] font-medium text-fog">The Solution</h2>
          <p className="mt-3 text-[14px] leading-relaxed text-fog-dim">{cs.solution}</p>
        </Reveal>
      </section>

      <CTA
        title="Have a Similar Challenge?"
        subtitle="Let's talk about what a solution like this could look like for your business."
      />
    </>
  );
}
