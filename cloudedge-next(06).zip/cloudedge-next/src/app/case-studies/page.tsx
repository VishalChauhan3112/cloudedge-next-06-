import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight } from "lucide-react";
import Reveal from "@/components/Reveal";
import Eyebrow from "@/components/Eyebrow";
import { CASE_STUDIES } from "@/lib/case-studies";

export const metadata: Metadata = {
  title: "Case Studies — CloudEdge Tech Services",
  description: "How CloudEdge has helped clients solve real infrastructure and IT challenges.",
};

export default function CaseStudiesPage() {
  return (
    <section className="mx-auto max-w-6xl px-6 pb-28 pt-40 md:px-10 md:pt-48">
      <Reveal className="text-center">
        <Eyebrow index="—" label="Case Studies" />
        <h1 className="mt-5 font-display text-6xl leading-[0.95] text-fog md:text-7xl">
          Real Work, Real Results
        </h1>
        <p className="mx-auto mt-6 max-w-xl text-[14.5px] leading-relaxed text-fog-dim">
          A closer look at how we&apos;ve helped clients solve real infrastructure and
          growth challenges.
        </p>
      </Reveal>

      <div className="mt-16 grid gap-6 md:grid-cols-2">
        {CASE_STUDIES.map((cs, i) => (
          <Reveal key={cs.slug} delay={i * 0.08}>
            <Link
              href={`/case-studies/${cs.slug}`}
              className="group flex h-full flex-col rounded-2xl border border-wire bg-panel p-8 shadow-[0_2px_12px_rgba(23,21,31,0.04)] transition-colors hover:border-signal/50"
            >
              <span className="font-mono text-[11px] uppercase tracking-wide text-signal-soft">
                {cs.industry} · {cs.service}
              </span>
              <h2 className="mt-3 text-[20px] font-medium leading-snug text-fog">{cs.title}</h2>
              <p className="mt-3 flex-1 text-[13.5px] leading-relaxed text-fog-dim">
                {cs.summary}
              </p>
              <div className="mt-6 flex items-center gap-2 font-mono text-[12px] text-signal-soft">
                Read case study
                <ArrowRight
                  size={14}
                  className="transition-transform group-hover:translate-x-1"
                />
              </div>
            </Link>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
