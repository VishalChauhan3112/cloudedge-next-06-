import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, MapPin, Briefcase } from "lucide-react";
import Reveal from "@/components/Reveal";
import Eyebrow from "@/components/Eyebrow";
import { JOBS } from "@/lib/jobs";

export const metadata: Metadata = {
  title: "Careers — CloudEdge Tech Services",
  description: "Open positions at CloudEdge Tech Services.",
};

export default function CareersPage() {
  return (
    <section className="mx-auto max-w-5xl px-6 pb-28 pt-40 md:px-10 md:pt-48">
      <Reveal className="text-center">
        <Eyebrow index="—" label="Careers" />
        <h1 className="mt-5 font-display text-6xl leading-[0.95] text-fog md:text-7xl">
          Open Positions
        </h1>
        <p className="mx-auto mt-6 max-w-xl text-[14.5px] leading-relaxed text-fog-dim">
          Join a team that&apos;s helping businesses across India and the US grow with
          confidence. Don&apos;t see a fit? Reach out anyway.
        </p>
      </Reveal>

      <div className="mt-16 border-t border-wire">
        {JOBS.length === 0 ? (
          <p className="py-12 text-center text-[14px] text-fog-dim">
            No open positions right now — check back soon.
          </p>
        ) : (
          JOBS.map((job, i) => (
            <Reveal key={job.slug} delay={Math.min(i * 0.05, 0.2)}>
              <Link
                href={`/careers/${job.slug}`}
                className="group flex flex-col gap-3 border-b border-wire py-7 transition-colors hover:bg-panel-hover md:flex-row md:items-center md:justify-between md:px-4"
              >
                <div>
                  <h3 className="text-[18px] font-medium text-fog">{job.title}</h3>
                  <div className="mt-2 flex flex-wrap items-center gap-4 font-mono text-[11px] uppercase tracking-wide text-fog-dimmer">
                    <span className="flex items-center gap-1.5">
                      <Briefcase size={12} /> {job.department}
                    </span>
                    <span className="flex items-center gap-1.5">
                      <MapPin size={12} /> {job.location}
                    </span>
                    <span>{job.type}</span>
                  </div>
                </div>
                <ArrowRight
                  size={20}
                  className="shrink-0 text-fog-dimmer opacity-0 transition-all duration-300 group-hover:translate-x-1 group-hover:text-signal group-hover:opacity-100"
                />
              </Link>
            </Reveal>
          ))
        )}
      </div>
    </section>
  );
}
