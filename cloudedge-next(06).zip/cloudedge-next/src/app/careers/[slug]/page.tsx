import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Link from "next/link";
import { ArrowLeft, MapPin, Briefcase, Clock } from "lucide-react";
import { JOBS, getJob } from "@/lib/jobs";
import Reveal from "@/components/Reveal";
import Eyebrow from "@/components/Eyebrow";
import ApplyForm from "@/components/ApplyForm";

export function generateStaticParams() {
  return JOBS.map((j) => ({ slug: j.slug }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const job = getJob(slug);
  if (!job) return {};
  return { title: `${job.title} — Careers — CloudEdge`, description: job.summary };
}

export default async function JobDetailPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const job = getJob(slug);
  if (!job) notFound();

  return (
    <section className="mx-auto max-w-3xl px-6 pb-28 pt-40 md:px-10 md:pt-48">
      <script
        type="application/ld+json"
        // eslint-disable-next-line react/no-danger
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "JobPosting",
            title: job.title,
            description: job.summary,
            employmentType: job.type.toUpperCase().includes("FULL")
              ? "FULL_TIME"
              : "OTHER",
            hiringOrganization: {
              "@type": "Organization",
              name: "CloudEdge Tech Services",
            },
            jobLocation: {
              "@type": "Place",
              address: job.location,
            },
          }),
        }}
      />
      <Reveal>
        <Link
          href="/careers"
          className="inline-flex items-center gap-2 font-mono text-[12px] text-fog-dim transition-colors hover:text-signal-soft"
        >
          <ArrowLeft size={14} /> All Positions
        </Link>
      </Reveal>

      <Reveal delay={0.05}>
        <Eyebrow index="—" label={job.department} />
      </Reveal>

      <Reveal delay={0.1}>
        <h1 className="mt-5 font-display text-4xl leading-[1] text-fog md:text-5xl">
          {job.title}
        </h1>
      </Reveal>

      <Reveal delay={0.15} className="mt-5 flex flex-wrap items-center gap-5 font-mono text-[12px] uppercase tracking-wide text-fog-dimmer">
        <span className="flex items-center gap-1.5">
          <MapPin size={13} /> {job.location}
        </span>
        <span className="flex items-center gap-1.5">
          <Clock size={13} /> {job.type}
        </span>
        <span className="flex items-center gap-1.5">
          <Briefcase size={13} /> {job.department}
        </span>
      </Reveal>

      <Reveal delay={0.2}>
        <p className="mt-8 text-[15px] leading-relaxed text-fog-dim">{job.summary}</p>
      </Reveal>

      <Reveal delay={0.25} className="mt-10">
        <h2 className="text-[15px] font-medium text-fog">What You&apos;ll Do</h2>
        <ul className="mt-4 flex flex-col gap-2.5">
          {job.responsibilities.map((r) => (
            <li key={r} className="flex items-start gap-2.5 text-[13.5px] text-fog-dim">
              <span className="mt-2 h-1 w-1 shrink-0 rounded-full bg-signal" />
              {r}
            </li>
          ))}
        </ul>
      </Reveal>

      <Reveal delay={0.3} className="mt-8">
        <h2 className="text-[15px] font-medium text-fog">What We&apos;re Looking For</h2>
        <ul className="mt-4 flex flex-col gap-2.5">
          {job.requirements.map((r) => (
            <li key={r} className="flex items-start gap-2.5 text-[13.5px] text-fog-dim">
              <span className="mt-2 h-1 w-1 shrink-0 rounded-full bg-signal" />
              {r}
            </li>
          ))}
        </ul>
      </Reveal>

      <Reveal delay={0.35} className="mt-14 rounded-2xl border border-wire bg-panel p-8 shadow-[0_2px_16px_rgba(23,21,31,0.05)]">
        <h2 className="text-[17px] font-medium text-fog">Apply for This Role</h2>
        <p className="mt-1 mb-7 text-[13px] text-fog-dim">
          We&apos;ll get back to you within a few business days.
        </p>
        <ApplyForm jobSlug={job.slug} jobTitle={job.title} />
      </Reveal>
    </section>
  );
}
