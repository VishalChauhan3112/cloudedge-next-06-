import Hero from "@/components/Hero";
import StatusStrip from "@/components/StatusStrip";
import Services from "@/components/Services";
import Process from "@/components/Process";
import Pricing from "@/components/Pricing";
import Testimonials from "@/components/Testimonials";
import JoinUs from "@/components/JoinUs";
import FAQ from "@/components/FAQ";
import CTA from "@/components/CTA";
import Contact from "@/components/Contact";

export default function Home() {
  return (
    <>
      <Hero />
      <StatusStrip />
      <Services />
      <Process />
      <Pricing />
      <Testimonials />
      <JoinUs />
      <FAQ />
      <CTA />
      <Contact />
    </>
  );
}
