"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { Search as SearchIcon, ArrowRight } from "lucide-react";
import Eyebrow from "@/components/Eyebrow";
import { buildSearchIndex } from "@/lib/search-index";

const INDEX = buildSearchIndex();

export default function SearchPage() {
  const [query, setQuery] = useState("");

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return [];
    return INDEX.filter(
      (item) =>
        item.title.toLowerCase().includes(q) ||
        item.description.toLowerCase().includes(q) ||
        item.category.toLowerCase().includes(q)
    );
  }, [query]);

  return (
    <section className="mx-auto max-w-3xl px-6 pb-28 pt-40 md:px-10 md:pt-48">
      <div className="text-center">
        <Eyebrow index="—" label="Search" />
        <h1 className="mt-5 font-display text-5xl leading-[0.95] text-fog md:text-6xl">
          Search CloudEdge
        </h1>
      </div>

      <div className="relative mt-10">
        <SearchIcon
          size={18}
          className="pointer-events-none absolute left-5 top-1/2 -translate-y-1/2 text-fog-dimmer"
        />
        <input
          type="text"
          autoFocus
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search services, blog posts, careers, resources…"
          className="w-full rounded-full border border-wire-light bg-panel py-4 pl-14 pr-6 text-[15px] text-fog placeholder:text-fog-dimmer shadow-[0_2px_16px_rgba(23,21,31,0.05)] focus:border-signal focus:outline-none"
        />
      </div>

      <div className="mt-10">
        {query.trim() === "" ? (
          <p className="text-center text-[13.5px] text-fog-dim">
            Start typing to search across services, blog posts, case studies, careers,
            and resources.
          </p>
        ) : results.length === 0 ? (
          <p className="text-center text-[13.5px] text-fog-dim">
            No results for &ldquo;{query}&rdquo;. Try a different term, or{" "}
            <Link href="/#contact" className="text-signal-soft hover:underline">
              contact us
            </Link>{" "}
            directly.
          </p>
        ) : (
          <ul className="divide-y divide-wire border-y border-wire">
            {results.map((item) => (
              <li key={item.url}>
                <Link
                  href={item.url}
                  className="group flex items-center justify-between gap-6 py-5 transition-colors hover:bg-panel-hover md:px-4"
                >
                  <div>
                    <span className="font-mono text-[10px] uppercase tracking-wide text-signal-soft">
                      {item.category}
                    </span>
                    <h2 className="mt-1 text-[16px] font-medium text-fog">{item.title}</h2>
                    <p className="mt-1 max-w-xl text-[13px] leading-relaxed text-fog-dim">
                      {item.description}
                    </p>
                  </div>
                  <ArrowRight
                    size={18}
                    className="hidden shrink-0 text-fog-dimmer opacity-0 transition-all duration-300 group-hover:translate-x-1 group-hover:text-signal group-hover:opacity-100 md:block"
                  />
                </Link>
              </li>
            ))}
          </ul>
        )}
      </div>
    </section>
  );
}
