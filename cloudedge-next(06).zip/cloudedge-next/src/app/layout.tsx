import type { Metadata } from "next";
import "./globals.css";
import Nav from "@/components/Nav";
import Footer from "@/components/Footer";

const title = "CloudEdge Tech Services — Technology Solutions That Drive Growth";
const description =
  "Managed IT, cybersecurity, cloud infrastructure, and digital transformation services for modern businesses across India and the US.";

export const metadata: Metadata = {
  metadataBase: new URL(process.env.SITE_URL || "http://localhost:3000"),
  title: {
    default: title,
    template: "%s",
  },
  description,
  openGraph: {
    title,
    description,
    siteName: "CloudEdge Tech Services",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title,
    description,
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="h-full">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:ital,wght@0,300;0,400;0,500;0,700;1,300&family=DM+Mono:wght@400;500&display=swap"
          rel="stylesheet"
        />
        <script
          type="application/ld+json"
          // eslint-disable-next-line react/no-danger
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "Organization",
              name: "CloudEdge Tech Services",
              description,
              url: process.env.SITE_URL || "http://localhost:3000",
              areaServed: ["India", "United States"],
              sameAs: [],
            }),
          }}
        />
      </head>
      <body className="min-h-full bg-void text-fog">
        <Nav />
        <main>{children}</main>
        <Footer />
      </body>
    </html>
  );
}
