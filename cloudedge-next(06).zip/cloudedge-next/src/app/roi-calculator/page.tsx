import type { Metadata } from "next";
import Reveal from "@/components/Reveal";
import Eyebrow from "@/components/Eyebrow";
import RoiCalculator from "@/components/RoiCalculator";
import CTA from "@/components/CTA";

export const metadata: Metadata = {
  title: "IT Downtime Cost Calculator — CloudEdge Tech Services",
  description: "Estimate how much IT downtime is costing your business, and what managed IT could save you.",
};

export default function RoiCalculatorPage() {
  return (
    <>
      <section className="mx-auto max-w-4xl px-6 pb-20 pt-40 md:px-10 md:pt-48">
        <Reveal className="text-center">
          <Eyebrow index="—" label="Downtime Cost Calculator" />
          <h1 className="mt-5 font-display text-5xl leading-[0.95] text-fog md:text-6xl">
            What Is Downtime Actually Costing You?
          </h1>
          <p className="mx-auto mt-6 max-w-xl text-[14.5px] leading-relaxed text-fog-dim">
            Adjust the numbers below to get a rough estimate of what IT downtime costs your
            business today, and what proactive managed IT could realistically save.
          </p>
        </Reveal>

        <Reveal delay={0.1} className="mt-14">
          <RoiCalculator />
        </Reveal>
      </section>

      <CTA
        title="Want a Real Assessment?"
        subtitle="This calculator is a starting point — we can give you an actual picture based on your environment."
      />
    </>
  );
}
