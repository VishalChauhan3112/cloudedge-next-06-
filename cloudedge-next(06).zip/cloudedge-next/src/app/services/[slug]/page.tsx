import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Link from "next/link";
import { ArrowLeft, Check } from "lucide-react";
import { SERVICES, getService } from "@/lib/services";
import ServiceIcon from "@/components/ServiceIcon";
import Reveal from "@/components/Reveal";
import Eyebrow from "@/components/Eyebrow";
import CTA from "@/components/CTA";

export function generateStaticParams() {
  return SERVICES.map((s) => ({ slug: s.slug }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const service = getService(slug);
  if (!service) return {};
  return {
    title: `${service.title} — CloudEdge Tech Services`,
    description: service.description,
  };
}

export default async function ServiceDetailPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const service = getService(slug);
  if (!service) notFound();

  const index = SERVICES.findIndex((s) => s.slug === slug);
  const prev = SERVICES[(index - 1 + SERVICES.length) % SERVICES.length];
  const next = SERVICES[(index + 1) % SERVICES.length];

  return (
    <>
      <section className="relative overflow-hidden pt-40 pb-20 md:pt-48">
        <div
          className="pointer-events-none absolute inset-0 opacity-[0.35]"
          style={{
            backgroundImage:
              "linear-gradient(to right, var(--wire) 1px, transparent 1px), linear-gradient(to bottom, var(--wire) 1px, transparent 1px)",
            backgroundSize: "64px 64px",
            maskImage: "radial-gradient(ellipse 80% 60% at 50% 0%, black 40%, transparent 100%)",
          }}
        />
        <div className="pointer-events-none absolute -top-40 left-1/2 h-[560px] w-[560px] -translate-x-1/2 rounded-full bg-signal/[0.07] blur-[140px]" />

        <div className="relative mx-auto max-w-3xl px-6 md:px-10">
          <Reveal>
            <Link
              href="/#services"
              className="inline-flex items-center gap-2 font-mono text-[12px] text-fog-dim transition-colors hover:text-signal-soft"
            >
              <ArrowLeft size={14} /> All Services
            </Link>
          </Reveal>

          <Reveal delay={0.05} className="mt-8 flex items-center gap-4">
            <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-xl border border-wire-light text-signal-soft">
              <ServiceIcon name={service.icon} size={26} />
            </div>
            <Eyebrow index={`/ ${service.n}`} label="Service" />
          </Reveal>

          <Reveal delay={0.1}>
            <h1 className="mt-6 font-display text-5xl leading-[0.95] text-fog md:text-6xl">
              {service.title}
            </h1>
          </Reveal>

          <Reveal delay={0.15}>
            <p className="mt-8 max-w-xl text-[15px] leading-relaxed text-fog-dim">
              {service.description}
            </p>
          </Reveal>

          <Reveal delay={0.2} className="mt-10 flex flex-wrap gap-3">
            {service.highlights.map((h) => (
              <span
                key={h}
                className="flex items-center gap-2 rounded-full border border-wire-light bg-panel px-4 py-2 text-[13px] text-fog"
              >
                <Check size={13} className="text-signal" />
                {h}
              </span>
            ))}
          </Reveal>

          <Reveal delay={0.25} className="mt-12">
            <Link
              href="/#contact"
              className="inline-flex items-center gap-2 rounded-full bg-signal px-7 py-3.5 font-mono text-[13px] font-medium tracking-wide text-white transition-transform hover:scale-[1.03]"
            >
              Talk To Us About This
            </Link>
          </Reveal>
        </div>
      </section>

      <div className="mx-auto max-w-3xl px-6 md:px-10">
        <div className="flex items-center justify-between border-t border-wire py-8">
          <Link
            href={`/services/${prev.slug}`}
            className="group flex items-center gap-3 text-fog-dim transition-colors hover:text-fog"
          >
            <ArrowLeft size={16} className="transition-transform group-hover:-translate-x-0.5" />
            <span>
              <span className="block font-mono text-[10px] uppercase tracking-wide text-fog-dimmer">
                Previous
              </span>
              <span className="text-[13.5px]">{prev.title}</span>
            </span>
          </Link>
          <Link
            href={`/services/${next.slug}`}
            className="group flex items-center gap-3 text-right text-fog-dim transition-colors hover:text-fog"
          >
            <span>
              <span className="block font-mono text-[10px] uppercase tracking-wide text-fog-dimmer">
                Next
              </span>
              <span className="text-[13.5px]">{next.title}</span>
            </span>
            <ArrowLeft
              size={16}
              className="rotate-180 transition-transform group-hover:translate-x-0.5"
            />
          </Link>
        </div>
      </div>

      <CTA />
    </>
  );
}
