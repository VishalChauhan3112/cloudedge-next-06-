import type { Metadata } from "next";
import AboutHero from "@/components/AboutHero";
import StatusStrip from "@/components/StatusStrip";
import Footprint from "@/components/Footprint";
import Values from "@/components/Values";
import CTA from "@/components/CTA";

export const metadata: Metadata = {
  title: "About — CloudEdge Tech Services",
  description:
    "CloudEdge Tech Services is a global consulting and technology partner driving measurable growth across India and the US.",
};

const PRINCIPLES = [
  "Precision",
  "Speed",
  "Long-Term Value",
  "Global Expertise",
  "Local Insight",
  "AI-Driven Transformation",
  "Sustainable Advantage",
];

export default function AboutPage() {
  return (
    <>
      <AboutHero />
      <StatusStrip items={PRINCIPLES} separator="star" />
      <Footprint />
      <Values />
      <CTA
        title="Ready to Lead Change?"
        subtitle="Whether you're a startup finding your footing or a Fortune 500 enterprise pushing new boundaries — we're ready to align with your vision and deliver excellence at every stage."
        primaryLabel="Get In Touch"
        primaryHref="/#contact"
        secondaryLabel="Explore Services"
        secondaryHref="/#services"
      />
    </>
  );
}
