import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import Eyebrow from "@/components/Eyebrow";

export default function NotFound() {
  return (
    <section className="mx-auto flex min-h-[70vh] max-w-2xl flex-col items-center justify-center px-6 text-center md:px-10">
      <Eyebrow index="404" label="Page Not Found" />
      <h1 className="mt-6 font-display text-7xl text-fog md:text-8xl">Lost In The Cloud</h1>
      <p className="mt-6 max-w-md text-[14.5px] leading-relaxed text-fog-dim">
        The page you&apos;re looking for doesn&apos;t exist or may have moved.
      </p>
      <Link
        href="/"
        className="group mt-9 inline-flex items-center gap-2 rounded-full bg-signal px-7 py-3.5 font-mono text-[13px] font-medium tracking-wide text-white transition-transform hover:scale-[1.03]"
      >
        <ArrowLeft size={15} className="transition-transform group-hover:-translate-x-0.5" />
        Back To Home
      </Link>
    </section>
  );
}
