import { NextRequest, NextResponse } from "next/server";
import { appendOne } from "@/lib/submissions";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// Where the owner gets notified when someone subscribes.
const NOTIFY_TO = "chohanv828@gmail.com";

/**
 * Sends the notification email via Resend's plain HTTP API (fetch — no SDK
 * install needed, so this works even without npm access). Requires
 * RESEND_API_KEY to be set; silently no-ops otherwise so the subscribe flow
 * still works (and the email is still stored) even before it's configured.
 */
async function notifyOwner(subscriberEmail: string) {
  const apiKey = process.env.RESEND_API_KEY;
  if (!apiKey) return { sent: false, reason: "RESEND_API_KEY not configured" };

  const from = process.env.RESEND_FROM || "CloudEdge Website <onboarding@resend.dev>";

  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      from,
      to: [NOTIFY_TO],
      subject: "New newsletter subscriber — CloudEdge",
      text: `New newsletter signup: ${subscriberEmail}\nSubmitted at: ${new Date().toISOString()}`,
    }),
  });

  if (!res.ok) {
    const body = await res.text().catch(() => "");
    return { sent: false, reason: `Resend API error: ${res.status} ${body}` };
  }
  return { sent: true };
}

export async function POST(req: NextRequest) {
  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ success: false, message: "Invalid request body." }, { status: 400 });
  }

  const email = String(body.email ?? "").trim();
  if (!email || !EMAIL_RE.test(email)) {
    return NextResponse.json(
      { success: false, message: "A valid email address is required." },
      { status: 400 }
    );
  }

  try {
    await appendOne("newsletter-subscribers.json", {
      email,
      subscribed_at: new Date().toISOString(),
    });
  } catch {
    return NextResponse.json(
      { success: false, message: "Could not save your subscription. Please try again." },
      { status: 500 }
    );
  }

  // Best-effort — a failed/unconfigured notification never blocks the subscribe itself.
  const notify = await notifyOwner(email).catch((e) => ({ sent: false, reason: String(e) }));
  if (!notify.sent) {
    console.warn("[newsletter] owner notification not sent:", notify.reason);
  }

  return NextResponse.json({ success: true, message: "Subscribed!" });
}
