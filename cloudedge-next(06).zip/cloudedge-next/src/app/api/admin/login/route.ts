import { NextRequest, NextResponse } from "next/server";
import { ADMIN_COOKIE, makeSessionToken } from "@/lib/admin-auth";

export async function POST(req: NextRequest) {
  const configured = process.env.ADMIN_PASSWORD;
  if (!configured) {
    return NextResponse.json(
      { success: false, message: "ADMIN_PASSWORD is not set on the server. See .env.example." },
      { status: 500 }
    );
  }

  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ success: false, message: "Invalid request." }, { status: 400 });
  }

  const password = String(body.password ?? "");
  if (password !== configured) {
    return NextResponse.json({ success: false, message: "Incorrect password." }, { status: 401 });
  }

  const res = NextResponse.json({ success: true });
  res.cookies.set(ADMIN_COOKIE, await makeSessionToken(), {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 24 * 7, // 7 days
  });
  return res;
}
