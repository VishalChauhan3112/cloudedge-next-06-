import { NextRequest, NextResponse } from "next/server";
import { appendOne } from "@/lib/submissions";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export async function POST(req: NextRequest) {
  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ success: false, message: "Invalid request body." }, { status: 400 });
  }

  const name = String(body.name ?? "").trim();
  const email = String(body.email ?? "").trim();
  const company = String(body.company ?? "").trim();
  const phone = String(body.phone ?? "").trim();
  const message = String(body.message ?? "").trim();
  const agree = Boolean(body.agree);

  // ── Server-side validation (mirrors the original contact.php rules) ──
  if (!name) {
    return NextResponse.json({ success: false, message: "Full name is required." }, { status: 400 });
  }
  if (!email || !EMAIL_RE.test(email)) {
    return NextResponse.json(
      { success: false, message: "A valid email address is required." },
      { status: 400 }
    );
  }
  if (message.length < 10) {
    return NextResponse.json(
      { success: false, message: "Message must be at least 10 characters." },
      { status: 400 }
    );
  }
  if (!agree) {
    return NextResponse.json(
      { success: false, message: "You must agree to the Privacy Policy." },
      { status: 400 }
    );
  }

  try {
    await appendOne("contact-submissions.json", {
      name,
      email,
      company: company || null,
      phone: phone || null,
      message,
      agreed: agree,
      ip_address: req.headers.get("x-forwarded-for") ?? "unknown",
      submitted_at: new Date().toISOString(),
    });
  } catch {
    return NextResponse.json(
      { success: false, message: "Could not save your message. Please try again." },
      { status: 500 }
    );
  }

  return NextResponse.json({ success: true, message: "Message sent successfully!" });
}
