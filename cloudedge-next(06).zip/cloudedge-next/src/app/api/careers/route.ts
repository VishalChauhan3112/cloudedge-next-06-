import { NextRequest, NextResponse } from "next/server";
import { appendOne } from "@/lib/submissions";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const NOTIFY_TO = "chohanv828@gmail.com";

async function notifyOwner(name: string, jobTitle: string, email: string) {
  const apiKey = process.env.RESEND_API_KEY;
  if (!apiKey) return;
  const from = process.env.RESEND_FROM || "CloudEdge Website <onboarding@resend.dev>";
  try {
    await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        from,
        to: [NOTIFY_TO],
        subject: `New application: ${jobTitle}`,
        text: `${name} (${email}) applied for ${jobTitle}.\nSubmitted at: ${new Date().toISOString()}`,
      }),
    });
  } catch (e) {
    console.warn("[careers] owner notification failed:", e);
  }
}

export async function POST(req: NextRequest) {
  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ success: false, message: "Invalid request body." }, { status: 400 });
  }

  const jobSlug = String(body.jobSlug ?? "").trim();
  const jobTitle = String(body.jobTitle ?? "").trim();
  const name = String(body.name ?? "").trim();
  const email = String(body.email ?? "").trim();
  const phone = String(body.phone ?? "").trim();
  const linkedin = String(body.linkedin ?? "").trim();
  const message = String(body.message ?? "").trim();

  if (!name) {
    return NextResponse.json({ success: false, message: "Full name is required." }, { status: 400 });
  }
  if (!email || !EMAIL_RE.test(email)) {
    return NextResponse.json(
      { success: false, message: "A valid email address is required." },
      { status: 400 }
    );
  }
  if (!message) {
    return NextResponse.json(
      { success: false, message: "Please tell us a bit about your fit for the role." },
      { status: 400 }
    );
  }

  try {
    await appendOne("job-applications.json", {
      job_slug: jobSlug,
      job_title: jobTitle,
      name,
      email,
      phone: phone || null,
      linkedin: linkedin || null,
      message,
      applied_at: new Date().toISOString(),
    });
  } catch {
    return NextResponse.json(
      { success: false, message: "Could not save your application. Please try again." },
      { status: 500 }
    );
  }

  await notifyOwner(name, jobTitle, email);

  return NextResponse.json({ success: true, message: "Application received!" });
}
