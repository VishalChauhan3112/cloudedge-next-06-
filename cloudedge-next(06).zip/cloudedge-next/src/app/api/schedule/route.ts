import { NextRequest, NextResponse } from "next/server";
import { appendOne } from "@/lib/submissions";

const MOBILE_RE = /^[+\d\s\-()]{7,20}$/;

export async function POST(req: NextRequest) {
  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ success: false, message: "Invalid request body." }, { status: 400 });
  }

  const date = String(body.date ?? "").trim();
  const time = String(body.time ?? "").trim();
  const fullName = String(body.fullName ?? "").trim();
  const mobile = String(body.mobile ?? "").trim();

  // ── Server-side validation (mirrors the original schedule.php rules) ──
  if (!date || !time) {
    return NextResponse.json(
      { success: false, message: "Please select both a date and a time slot." },
      { status: 400 }
    );
  }
  if (!fullName) {
    return NextResponse.json(
      { success: false, message: "Please enter your full name." },
      { status: 400 }
    );
  }
  if (!mobile || !MOBILE_RE.test(mobile)) {
    return NextResponse.json(
      { success: false, message: "Please enter a valid mobile number." },
      { status: 400 }
    );
  }

  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const picked = new Date(date);
  if (Number.isNaN(picked.getTime()) || picked < today) {
    return NextResponse.json(
      { success: false, message: "Please select a future date." },
      { status: 400 }
    );
  }

  try {
    await appendOne("call-bookings.json", {
      full_name: fullName,
      mobile,
      call_date: date,
      call_time: time,
      booked_at: new Date().toISOString(),
    });
  } catch {
    return NextResponse.json(
      { success: false, message: "Could not save booking. Please try again." },
      { status: 500 }
    );
  }

  const formatted = picked.toLocaleDateString("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });
  const [h, m] = time.split(":").map(Number);
  const period = h >= 12 ? "pm" : "am";
  const hour12 = h % 12 === 0 ? 12 : h % 12;
  const formattedTime = `${hour12}:${String(m).padStart(2, "0")}${period}`;

  return NextResponse.json({
    success: true,
    message: `${formatted} at ${formattedTime}`,
  });
}
